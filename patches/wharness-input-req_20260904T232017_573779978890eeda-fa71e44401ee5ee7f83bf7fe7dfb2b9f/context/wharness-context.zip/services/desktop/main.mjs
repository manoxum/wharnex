import { app, BrowserWindow, ClipboardItem, WebContentsView, clipboard, dialog, ipcMain, nativeImage, session, shell } from 'electron'
import { createHash, randomUUID } from 'node:crypto'
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { ChatGPTSubmitCoordinator, dispatchChatGPTSubmit } from './chatgpt-input.mjs'
import { ChatGPTUploadCoordinator, pasteWithUploadRetry, plannerPromptMarkdown, waitForChatGPTReady } from './chatgpt-upload.mjs'
import { persistChatAttachmentFiles, readStoredAttachmentPreview, removeStoredChatAttachments, storedAttachmentPath } from './chat-attachment-store.mjs'
import { chatGPTAssistantTurnCountScript, chatGPTComposerReadyScript, chatGPTExpectedDownloadScript, chatGPTResponseCompletionScript, chatGPTFillComposerScript, chatGPTFocusComposerScript, chatGPTSubmitScript, chatGPTVisibleActivityScript } from './chatgpt-dom.mjs'
import { pathSize, restoreBrowserSession, snapshotBrowserSession } from './browser-session-data.mjs'
import { chatGPTNavigationDisposition, chatInputSettleDelay, chromeCompatibleUserAgent, contextBundleURL, decodeUserAttachment, isChatGPTAuthURL, isHTTPS, isTrustedChatGPTOrigin, normalizeBounds, requireLocalHTTPURL, requireTrustedChatGPTURL, sanitizeChatCacheKey, sanitizeChatGPTAuthMode, sanitizeDiagnosticURL, sanitizeSessionId, canonicalWharnessBundleDownload, validateWharnessBundleDownload, validateWharnessPlanFile, wharnessBundleRequestIdFromFilename, wharnessPlanRequestIdFromFilename } from './security.mjs'
import { shouldAttachProjectContext } from './chatgpt-context.mjs'
import { confirmChatGPTAffinity, createChatGPTAffinityTracker, markChatGPTAffinitySubmitted, observeChatGPTAffinity, proposeChatGPTAffinity, publicChatGPTAffinity, rejectChatGPTAffinity, syncChatGPTAffinity } from './chatgpt-affinity.mjs'
import { chatGPTStalledRecoveryPrompt, chooseChatGPTRecoveryAction, commitChatGPTRecoveryAction, createChatGPTRecoveryState, isChatGPTConversationTransportURL, isRecoverableChatGPTNetworkError, noteChatGPTRecoveryAssistantCount, noteChatGPTRecoveryFault, noteChatGPTRecoveryProgress } from './chatgpt-recovery.mjs'
import { chatGPTSessionProbeExpression, closeManagedBrowserAuth, electronCookieDetails, launchManagedBrowserAuth, managedBrowserProfileDirectory } from './managed-browser-auth.mjs'
import { ProjectWindowRegistry } from './project-window-registry.mjs'
import { parseRemoteInputResponse, remoteInputPayload } from './remote-input.mjs'

const here = path.dirname(fileURLToPath(import.meta.url))
const FRONTEND_URL = requireLocalHTTPURL(process.env.WHARNESS_FRONTEND_URL || 'http://127.0.0.1:5173', 'Frontend URL').href
const BACKEND_URL = requireLocalHTTPURL(process.env.WHARNESS_API_URL || 'http://127.0.0.1:8080', 'Backend URL').href
const FRONTEND_ORIGIN = new URL(FRONTEND_URL).origin
const CHATGPT_URL = 'https://chatgpt.com/'
const CHATGPT_LOGIN_URL = 'https://chatgpt.com/auth/login'
const CHATGPT_PARTITION = 'persist:wharness-chatgpt'
const MAX_CONTEXT_BYTES = 256 * 1024 * 1024
const MAX_PLAN_BYTES = 2 * 1024 * 1024
const MAX_EXECUTION_BUNDLE_BYTES = 16 * 1024 * 1024
const MAX_CHAT_ATTACHMENT_BYTES = 25 * 1024 * 1024
const MAX_CHAT_ATTACHMENTS_BYTES = 100 * 1024 * 1024
const MAX_CHAT_ATTACHMENTS = 10
const MAX_CHAT_ARTIFACTS = 4
const MAX_CHAT_ARTIFACT_BYTES = 2 * 1024 * 1024
const MAX_CHAT_ARTIFACTS_BYTES = 6 * 1024 * 1024
const CHATGPT_CHROMIUM_VERSION = '152.0.7977.65'
const CHATGPT_USER_AGENT = chromeCompatibleUserAgent(process.platform, CHATGPT_CHROMIUM_VERSION)
const CHATGPT_ACCEPT_LANGUAGES = 'pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7'
const SAFE_ATTACHMENT_IMAGE_MIMES = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/bmp', 'image/avif'])
const MAX_ATTACHMENT_THUMBNAIL_SOURCE_BYTES = 8 * 1024 * 1024

let mainWindow
let chatgptViews = new Map()
const chatGPTAuthBrowsers = new Map()
const desktopWindows = new Map()
const projectWindowRegistry = new ProjectWindowRegistry()
let quitting = false
const preparedChatGPTDrafts = new Map()
const pendingChatGPTComments = new Map()
const flushingChatGPTComments = new Set()
const recentChatGPTCommentIds = new Map()
const recentChatGPTCommentFingerprints = new Map()
const chatGPTActivityFingerprints = new Map()
const expectedChatGPTBundles = new Map()
const EXPECTED_BUNDLE_TTL_MS = 60 * 60 * 1000
const DOM_DOWNLOAD_POLL_MS = 2_000
const DOM_DOWNLOAD_RETRY_MS = 5_000
const BUNDLE_COMPLETION_GRACE_MS = 4_000
const BUNDLE_CONTINUATION_BASE_MS = 5_000
let chatGPTDownloadPoller
let recentExpectedDownload
const chatGPTUploads = new ChatGPTUploadCoordinator()
const chatGPTSubmissions = new ChatGPTSubmitCoordinator()

function securePreferences(extra = {}) {
  return {
    nodeIntegration: false,
    contextIsolation: true,
    sandbox: true,
    webSecurity: true,
    allowRunningInsecureContent: false,
    webviewTag: false,
    ...extra,
  }
}

function windowStateForWebContents(webContents) {
  if (!webContents) return undefined
  return [...desktopWindows.values()].find((state) => state.window?.webContents?.id === webContents.id)
}

function trustedSender(event) {
  const state = windowStateForWebContents(event?.sender)
  if (!state || state.window.isDestroyed()) throw new Error('Untrusted IPC sender')
  return state
}

function windowStateForEntry(entry) {
  return entry ? desktopWindows.get(entry.ownerWindowId) : undefined
}

function activeChatGPTEntry(windowState) {
  const state = windowState || windowStateForEntry([...chatgptViews.values()].find((entry) => entry.view.isVisible?.()))
  return state?.activeChatGPTKey ? chatgptViews.get(state.activeChatGPTKey) : undefined
}

function sendToWindowState(state, channel, payload) {
  if (state?.window && !state.window.isDestroyed()) state.window.webContents.send(channel, payload)
}

function sendToChatGPTKey(cacheKey, channel, payload) {
  const entry = cacheKey ? chatgptViews.get(cacheKey) : undefined
  const state = windowStateForEntry(entry)
  if (state) sendToWindowState(state, channel, payload)
}

function acquireProjectForWindow(windowState, value) {
  const lock = projectWindowRegistry.acquire(windowState.id, value)
  if (!lock.ok) {
    const owner = desktopWindows.get(lock.ownerWindowId)
    if (owner?.window && !owner.window.isDestroyed()) { owner.window.show(); owner.window.focus() }
    return { ...lock, message: 'Este projeto já está aberto noutra janela do Wharness. A janela proprietária foi trazida para a frente.' }
  }
  windowState.projects.add(lock.path)
  return lock
}

function releaseProjectForWindow(windowState, value) {
  const result = projectWindowRegistry.release(windowState.id, value)
  if (result.released) windowState.projects.delete(result.path)
  return result
}

function releaseWindowProjects(windowState) {
  projectWindowRegistry.releaseWindow(windowState.id)
  windowState.projects.clear()
}

function windowLayoutPath() { return path.join(app.getPath('userData'), 'wharness-window-layout.json') }

function persistWindowLayout(ids = [...desktopWindows.values()].filter((state) => !state.window.isDestroyed()).map((state) => state.id)) {
  try {
    writeFileSync(windowLayoutPath(), JSON.stringify({ version: 1, windows: [...new Set(ids)].slice(0, 12) }), { mode: 0o600 })
  } catch (error) { console.warn('[windows] layout persistence failed', error) }
}

function loadWindowLayout() {
  try {
    const parsed = JSON.parse(readFileSync(windowLayoutPath(), 'utf8'))
    const windows = Array.isArray(parsed?.windows) ? parsed.windows.filter((item) => typeof item === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(item)) : []
    return windows.length ? [...new Set(windows)].slice(0, 12) : ['primary']
  } catch { return ['primary'] }
}

function restartIntentPath() { return path.join(app.getPath('userData'), 'wharness-window-restart-intent.json') }

function persistRestartIntent(scope, currentWindowId) {
  try {
    writeFileSync(restartIntentPath(), JSON.stringify({ version: 1, scope, current_window_id: currentWindowId, created_at: Date.now() }), { mode: 0o600 })
  } catch (error) { console.warn('[windows] restart intent persistence failed', error) }
}

function consumeRestartIntent() {
  try {
    const filename = restartIntentPath()
    const parsed = JSON.parse(readFileSync(filename, 'utf8'))
    try { rmSync(filename, { force: true }) } catch { /* best effort */ }
    const scope = parsed?.scope === 'current' ? 'current' : parsed?.scope === 'all' ? 'all' : ''
    const currentWindowId = typeof parsed?.current_window_id === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(parsed.current_window_id) ? parsed.current_window_id : ''
    const createdAt = Number(parsed?.created_at || 0)
    if (!scope || !currentWindowId || !Number.isFinite(createdAt) || Date.now() - createdAt > 10 * 60 * 1000) return undefined
    return { scope, currentWindowId }
  } catch { return undefined }
}

function canonicalBundleFilename(requestId) {
  const id = String(requestId || '').trim()
  const filename = `wharness-bundle-${id}.zip`
  if (wharnessBundleRequestIdFromFilename(filename) !== id) throw new Error('Invalid Wharness request id for bundle transport')
  return filename
}

function armExpectedChatGPTBundle(cacheKey, requestId, assistantBaseline = 0, recoveryBootstrap = '') {
  const key = sanitizeChatCacheKey(cacheKey)
  const filename = canonicalBundleFilename(requestId)
  const prior = expectedChatGPTBundles.get(key)
  const sameRequest = prior?.requestId === String(requestId)
  expectedChatGPTBundles.set(key, {
    requestId: String(requestId), filename,
    armedAt: sameRequest ? prior.armedAt : Date.now(),
    assistantBaseline: Math.max(0, Number(assistantBaseline) || 0),
    lastDOMClick: 0,
    settledAt: 0,
    continuationCount: sameRequest ? Number(prior.continuationCount || 0) : 0,
    lastContinuationAt: sameRequest ? Number(prior.lastContinuationAt || 0) : 0,
    recoveryBootstrap: String(recoveryBootstrap || (sameRequest ? prior?.recoveryBootstrap : '') || ''),
    recovery: createChatGPTRecoveryState(Date.now()),
  })
  return filename
}

async function chatGPTAssistantTurnCount(wc) {
  try {
    const count = await wc.executeJavaScript(chatGPTAssistantTurnCountScript(), true)
    return Math.max(0, Number(count) || 0)
  } catch {
    return 0
  }
}

function expectedChatGPTBundleForDownload(sourceWebContents, sourceFilename = '') {
  const canonicalRequestId = wharnessBundleRequestIdFromFilename(path.basename(String(sourceFilename || '')))
  if (canonicalRequestId) {
    for (const [key, expected] of expectedChatGPTBundles) {
      if (expected.requestId === canonicalRequestId) return { key, ...expected }
    }
  }
  const sourceEntry = sourceWebContents && [...chatgptViews.entries()].find(([, candidate]) => candidate.view.webContents.id === sourceWebContents.id)
  if (sourceEntry) {
    const expected = expectedChatGPTBundles.get(sourceEntry[0])
    if (expected && Date.now() - expected.armedAt <= EXPECTED_BUNDLE_TTL_MS) return { key: sourceEntry[0], ...expected }
  }
  if (recentExpectedDownload && Date.now() - recentExpectedDownload.at <= 12_000) {
    const expected = expectedChatGPTBundles.get(recentExpectedDownload.key)
    if (expected?.requestId === recentExpectedDownload.requestId) return { key: recentExpectedDownload.key, ...expected }
  }
  return undefined
}

function chatGPTPartitionPath() {
  return path.join(app.getPath('userData'), 'Partitions', 'wharness-chatgpt')
}

function managedAuthProfilePath() {
  return managedBrowserProfileDirectory(app.getPath('userData'))
}

function pendingBrowserImportPath() {
  return path.join(app.getPath('userData'), '.wharness-browser-session-import.whbs')
}

function closeChatGPTViewsForWindow(windowState) {
  for (const [key, entry] of [...chatgptViews.entries()]) if (entry.ownerWindowId === windowState.id) releaseChatGPTView(key, windowState)
  windowState.activeChatGPTKey = ''
  windowState.chatgptVisible = false
}

function closeAllChatGPTViews() {
  for (const record of chatGPTAuthBrowsers.values()) {
    record.cancelled = true
    void closeManagedBrowserAuth(record)
  }
  chatGPTAuthBrowsers.clear()
  for (const entry of chatgptViews.values()) {
    if (!entry.view.webContents.isDestroyed()) entry.view.webContents.close()
  }
  chatgptViews = new Map()
  for (const state of desktopWindows.values()) { state.activeChatGPTKey = ''; state.chatgptVisible = false }
}

function touchChatGPTEntry(entry) {
  entry.lastUsed = Date.now()
}

function chatGPTEntryForWebContentsID(webContentsId) {
  if (webContentsId == null) return undefined
  return [...chatgptViews.entries()].find(([, candidate]) => candidate.view.webContents.id === webContentsId)
}

function noteChatGPTNetworkActivity(details, phase = 'network') {
  const match = chatGPTEntryForWebContentsID(details?.webContentsId)
  if (!match) return
  const [key, entry] = match
  entry.lastNetworkActivity = Date.now()
  const expected = expectedChatGPTBundles.get(key)
  if (expected?.recovery && isChatGPTConversationTransportURL(details?.url)) {
    noteChatGPTRecoveryProgress(expected.recovery, `${phase}:${details?.id || ''}:${details?.method || ''}`, Date.now())
  }
}

function noteChatGPTNetworkFailure(details) {
  const match = chatGPTEntryForWebContentsID(details?.webContentsId)
  if (!match || !isRecoverableChatGPTNetworkError(details?.error)) return false
  const [key] = match
  const expected = expectedChatGPTBundles.get(key)
  if (!expected?.recovery) return false
  const relevant = details?.resourceType === 'mainFrame' || isChatGPTConversationTransportURL(details?.url)
  if (!relevant) return false
  noteChatGPTRecoveryFault(expected.recovery, String(details?.error || 'ChatGPT network transport failed'), Date.now())
  console.warn(`[chatgpt-recovery] network-fault key=${key} request=${expected.requestId} error=${String(details?.error || 'unknown')}`)
  return true
}

function requireOwnedChatGPTEntry(cacheKey, entry) {
  const key = sanitizeChatCacheKey(cacheKey)
  if (!entry || entry.ownerKey !== key || chatgptViews.get(key) !== entry) {
    throw new Error('ChatGPT view ownership mismatch')
  }
  return { key, entry, wc: entry.view.webContents }
}

function releaseChatGPTView(cacheKey, ownerState) {
  const key = sanitizeChatCacheKey(cacheKey)
  const entry = chatgptViews.get(key)
  if (!entry) return false
  if (ownerState && entry.ownerWindowId !== ownerState.id) throw new Error('ChatGPT view belongs to another Wharness window')
  cancelExternalAuthentication(key)
  clearTimeout(entry.authProbeTimer)
  chatgptViews.delete(key)
  preparedChatGPTDrafts.delete(key)
  pendingChatGPTComments.delete(key)
  flushingChatGPTComments.delete(key)
  chatGPTActivityFingerprints.delete(key)
  expectedChatGPTBundles.delete(key)
  const state = windowStateForEntry(entry)
  if (state?.activeChatGPTKey === key) {
    state.activeChatGPTKey = ''
    state.chatgptVisible = false
  }
  if (!entry.view.webContents.isDestroyed()) entry.view.webContents.close()
  console.log(`[chatgpt-instance] released key=${key} window=${entry.ownerWindowId}`)
  return true
}

function setChatGPTBounds(value, windowState) {
  const bounds = normalizeBounds(value, windowState?.window?.getContentBounds())
  const entry = activeChatGPTEntry(windowState)
  if (!bounds || !entry) return false
  windowState.chatgptBounds = bounds
  entry.view.setBounds(bounds)
  return true
}

function currentChatGPTState(cacheKey = '', windowState) {
  const defaultKey = windowState?.activeChatGPTKey || ''
  const key = cacheKey ? sanitizeChatCacheKey(cacheKey) : defaultKey
  const entry = key ? chatgptViews.get(key) : undefined
  if (entry && windowState && entry.ownerWindowId !== windowState.id) throw new Error('ChatGPT view belongs to another Wharness window')
  const wc = entry?.view.webContents
  return {
    cacheKey: key,
    url: wc?.getURL() || CHATGPT_URL,
    title: wc?.getTitle() || 'ChatGPT',
    loading: entry?.loading ?? true,
    canGoBack: Boolean(wc?.navigationHistory.canGoBack()),
    canGoForward: Boolean(wc?.navigationHistory.canGoForward()),
    externalAuthProvider: entry?.externalAuthProvider || '',
    authMode: entry?.authMode || 'external',
    authWindowOpen: Boolean(key && chatGPTAuthBrowsers.has(key)),
    authenticated: Boolean(entry?.authenticated),
    ...publicChatGPTAffinity(entry?.affinity),
  }
}

function publishChatGPTState(key = '') {
  if (!key) {
    for (const state of desktopWindows.values()) if (state.activeChatGPTKey) publishChatGPTState(state.activeChatGPTKey)
    return
  }
  const entry = chatgptViews.get(key)
  const state = windowStateForEntry(entry)
  if (!state || state.activeChatGPTKey !== key) return
  sendToWindowState(state, 'wharness:chatgpt:state', currentChatGPTState(key, state))
}

function isChatGPTNewChatSurfaceURL(value) {
  try {
    const trusted = requireTrustedChatGPTURL(value)
    const pathname = new URL(trusted).pathname
    return pathname === '/' || pathname === ''
  } catch { return false }
}

function observeChatGPTAffinityURL(cacheKey, entry, value) {
  const candidate = observeChatGPTAffinity(entry.affinity, {
    home: isChatGPTNewChatSurfaceURL(value),
    conversationUrl: canonicalChatGPTConversationURL(value),
  })
  if (candidate) console.log(`[chatgpt-affinity] candidate key=${cacheKey} url=${sanitizeDiagnosticURL(candidate)}`)
  return candidate
}

function syncChatGPTAffinityURL(cacheKey, entry, linkedURL = '') {
  const linkedConversation = canonicalChatGPTConversationURL(linkedURL)
  const currentURL = entry.view.webContents.getURL()
  syncChatGPTAffinity(entry.affinity, linkedConversation, !linkedConversation && isChatGPTNewChatSurfaceURL(currentURL))
  console.log(`[chatgpt-affinity] sync key=${cacheKey} phase=${entry.affinity.phase} linked=${sanitizeDiagnosticURL(linkedConversation || CHATGPT_URL)}`)
  return linkedConversation
}

function proposeCurrentChatGPTAffinity(cacheKey, entry, linkedConversation, currentConversation) {
  if (!currentConversation || !linkedConversation || currentConversation === linkedConversation) return currentConversation
  const candidate = proposeChatGPTAffinity(entry.affinity, currentConversation)
  if (candidate) {
    console.log(`[chatgpt-affinity] rebind-candidate key=${cacheKey} url=${sanitizeDiagnosticURL(candidate)}`)
    publishChatGPTState(cacheKey)
  }
  return currentConversation
}

function noteChatGPTRendererFault(cacheKey, reason) {
  const expected = expectedChatGPTBundles.get(cacheKey)
  if (!expected?.recovery) return false
  noteChatGPTRecoveryFault(expected.recovery, reason, Date.now())
  console.warn(`[chatgpt-recovery] renderer-fault key=${cacheKey} request=${expected.requestId} error=${reason}`)
  return true
}

function settleChatGPTAffinityAfterSubmit(cacheKey, entry, conversationURL) {
  const concrete = canonicalChatGPTConversationURL(conversationURL)
  if (!concrete) return ''
  const observed = observeChatGPTAffinityURL(cacheKey, entry, concrete)
  let candidate = observed
  if (!candidate && !entry.affinity.boundURL && ['unbound', 'armed'].includes(entry.affinity.phase)) {
    candidate = proposeChatGPTAffinity(entry.affinity, concrete)
  } else if (!candidate && entry.affinity.phase === 'candidate' && entry.affinity.candidateURL === concrete) {
    candidate = concrete
  }
  if (candidate) {
    console.log(`[chatgpt-affinity] definitive-candidate key=${cacheKey} url=${sanitizeDiagnosticURL(candidate)}`)
    publishChatGPTState(cacheKey)
  }
  return concrete
}

async function refreshEmbeddedChatGPTAuthentication(cacheKey, entry) {
  const wc = entry?.view?.webContents
  if (!wc || wc.isDestroyed()) return
  const probedURL = wc.getURL()
  if (!isTrustedChatGPTOrigin(probedURL) || isChatGPTAuthURL(probedURL) || entry.externalAuthProvider) {
    if (entry.authenticated) {
      entry.authenticated = false
      publishChatGPTState(cacheKey)
    }
    return
  }
  try {
    const authenticated = Boolean(await wc.executeJavaScript(chatGPTSessionProbeExpression(), true))
    if (wc.isDestroyed() || wc.getURL() !== probedURL || entry.externalAuthProvider) return
    if (entry.authenticated !== authenticated) {
      entry.authenticated = authenticated
      publishChatGPTState(cacheKey)
    }
  } catch {
    // Keep the previous state on transient page/network failures instead of
    // falsely asking an already-authenticated user to sign in again.
  }
}

function scheduleEmbeddedChatGPTAuthenticationProbe(cacheKey, entry, delayMs = 120) {
  clearTimeout(entry.authProbeTimer)
  entry.authProbeTimer = setTimeout(() => {
    entry.authProbeTimer = undefined
    void refreshEmbeddedChatGPTAuthentication(cacheKey, entry)
  }, delayMs)
}

function publishPlanDownload(payload) {
  sendToChatGPTKey(payload?.cacheKey || '', 'wharness:chatgpt:plan-downloaded', payload)
}

function publishPlanDownloadError(message, filename = '', cacheKey = '') {
  console.error(`[chatgpt-plan-download] ${message}${filename ? ` file=${filename}` : ''}${cacheKey ? ` key=${cacheKey}` : ''}`)
  sendToChatGPTKey(cacheKey, 'wharness:chatgpt:plan-download-error', { message, filename, cacheKey })
}

function publishBundleDownload(payload) {
  sendToChatGPTKey(payload?.cacheKey || '', 'wharness:chatgpt:bundle-downloaded', payload)
}

function publishBundleDownloadError(message, filename = '', cacheKey = '') {
  console.error(`[chatgpt-bundle-download] ${message}${filename ? ` file=${filename}` : ''}${cacheKey ? ` key=${cacheKey}` : ''}`)
  sendToChatGPTKey(cacheKey, 'wharness:chatgpt:bundle-download-error', { message, filename, cacheKey })
}

function registerChatGPTPlanDownloads(chatSession) {
  chatSession.on('will-download', (_event, item, sourceWebContents) => {
    // This handler is registered on the dedicated persist:wharness-chatgpt
    // partition. A generated attachment can be served through an internal
    // download WebContents rather than the visible ChatGPT WebContentsView, so
    // do not require object identity here. The strict filename + JSON protocol
    // + request_id checks below remain the authority for plan interception.
    const sourceFilename = item.getFilename()
    const expectedBundle = expectedChatGPTBundleForDownload(sourceWebContents, sourceFilename)
    const sourceCacheKey = expectedBundle?.key || chatGPTKeyForWebContents(sourceWebContents)
    let bundleCandidate
    try {
      bundleCandidate = canonicalWharnessBundleDownload(sourceFilename, expectedBundle?.requestId || '', item.getMimeType?.() || '')
    } catch (error) {
      item.cancel()
      publishBundleDownloadError(error instanceof Error ? error.message : String(error), sourceFilename, sourceCacheKey)
      return
    }
    if (bundleCandidate) {
      const filename = bundleCandidate.filename
      const bundleRequestId = bundleCandidate.requestId
      const sourceURL = sourceWebContents?.getURL?.() || ''
      if (bundleCandidate.normalized) {
        console.warn(`[chatgpt-bundle-download] normalized sourceFile=${sourceFilename} canonicalFile=${filename} request=${bundleRequestId}`)
      }
      console.log(`[chatgpt-bundle-download] started file=${filename} source=${sanitizeDiagnosticURL(sourceURL)}`)
      const total = item.getTotalBytes()
      if (total > MAX_EXECUTION_BUNDLE_BYTES) {
        item.cancel()
        publishBundleDownloadError('Bundle Wharness excede o limite de 16 MiB.', filename, sourceCacheKey)
        return
      }
      const dir = path.join(app.getPath('temp'), 'wharness-bundles')
      const savePath = path.join(dir, filename)
      try {
        mkdirSync(dir, { recursive: true, mode: 0o700 })
        item.setSavePath(savePath)
      } catch (error) {
        item.cancel()
        publishBundleDownloadError(`Não foi possível preparar o bundle: ${error instanceof Error ? error.message : String(error)}`, filename, sourceCacheKey)
        return
      }
      item.on('updated', () => {
        if (item.getReceivedBytes() > MAX_EXECUTION_BUNDLE_BYTES) {
          item.cancel()
          publishBundleDownloadError('Bundle Wharness excede o limite de 16 MiB.', filename, sourceCacheKey)
        }
      })
      item.once('done', async (_doneEvent, state) => {
        if (state !== 'completed') {
          if (state !== 'cancelled') publishBundleDownloadError(`Download do bundle terminou em estado ${state}.`, filename, sourceCacheKey)
          return
        }
        try {
          const bytes = await readFile(savePath)
          if (bytes.byteLength > MAX_EXECUTION_BUNDLE_BYTES) throw new Error('Bundle Wharness excede o limite de 16 MiB.')
          const validated = validateWharnessBundleDownload(filename, bytes)
          publishBundleDownload({ cacheKey: sourceCacheKey, filename, requestId: validated.requestId, contentBase64: bytes.toString('base64'), bytes: bytes.byteLength, sourceFilename, normalizedFilename: bundleCandidate.normalized })
          if (expectedBundle?.key && expectedBundle.requestId === validated.requestId) expectedChatGPTBundles.delete(expectedBundle.key)
          console.log(`[chatgpt-bundle-download] imported file=${filename} bytes=${bytes.byteLength}`)
        } catch (error) {
          publishBundleDownloadError(error instanceof Error ? error.message : String(error), filename, sourceCacheKey)
        } finally {
          try { await rm(savePath, { force: true }) } catch { /* best effort temp cleanup */ }
        }
      })
      return
    }
    if (sourceFilename.startsWith('wharness-bundle-')) {
      item.cancel()
      publishBundleDownloadError('Nome do bundle inválido; esperado wharness-bundle-<request_id>.zip.', sourceFilename, sourceCacheKey)
      return
    }

    const filename = sourceFilename
    const requestId = wharnessPlanRequestIdFromFilename(filename)
    if (!requestId) {
      if (filename.startsWith('wharness-plan-')) {
        item.cancel()
        publishPlanDownloadError('Nome do ficheiro de plano inválido; esperado wharness-plan-<request_id>.json.', filename, sourceCacheKey)
      }
      return
    }
    const sourceURL = sourceWebContents?.getURL?.() || ''
    console.log(`[chatgpt-plan-download] started file=${filename} source=${sanitizeDiagnosticURL(sourceURL)}`)

    const total = item.getTotalBytes()
    if (total > MAX_PLAN_BYTES) {
      item.cancel()
      publishPlanDownloadError('Plano Wharness excede o limite de 2 MiB.', filename, sourceCacheKey)
      return
    }

    const dir = path.join(app.getPath('temp'), 'wharness-plans')
    const savePath = path.join(dir, filename)
    try {
      mkdirSync(dir, { recursive: true, mode: 0o700 })
      item.setSavePath(savePath)
    } catch (error) {
      item.cancel()
      publishPlanDownloadError(`Não foi possível preparar o download: ${error instanceof Error ? error.message : String(error)}`, filename, sourceCacheKey)
      return
    }

    item.on('updated', () => {
      if (item.getReceivedBytes() > MAX_PLAN_BYTES) {
        item.cancel()
        publishPlanDownloadError('Plano Wharness excede o limite de 2 MiB.', filename, sourceCacheKey)
      }
    })

    item.once('done', async (_doneEvent, state) => {
      if (state !== 'completed') {
        if (state !== 'cancelled') publishPlanDownloadError(`Download do plano terminou em estado ${state}.`, filename, sourceCacheKey)
        return
      }
      try {
        const bytes = await readFile(savePath)
        if (bytes.byteLength > MAX_PLAN_BYTES) throw new Error('Plano Wharness excede o limite de 2 MiB.')
        const text = bytes.toString('utf8')
        const validated = validateWharnessPlanFile(filename, text)
        publishPlanDownload({ cacheKey: sourceCacheKey, filename, requestId: validated.requestId, text: validated.text, bytes: bytes.byteLength })
        console.log(`[chatgpt-plan-download] imported file=${filename} bytes=${bytes.byteLength}`)
      } catch (error) {
        publishPlanDownloadError(error instanceof Error ? error.message : String(error), filename, sourceCacheKey)
      } finally {
        try { await rm(savePath, { force: true }) } catch { /* best effort temp cleanup */ }
      }
    })
  })
}

function chatGPTKeyForEntry(entry) {
  const key = String(entry?.ownerKey || '')
  if (!key || chatgptViews.get(key) !== entry) return ''
  return key
}

function chatGPTKeyForWebContents(webContents) {
  if (!webContents || webContents.isDestroyed?.()) return ''
  for (const [key, entry] of chatgptViews) {
    if (entry.view.webContents.id === webContents.id && entry.ownerKey === key) return key
  }
  return ''
}

function publishExternalAuth(entry, provider, url) {
  entry.externalAuthProvider = provider || 'OpenAI'
  entry.view.setVisible(false)
  const state = windowStateForEntry(entry)
  if (state) {
    sendToWindowState(state, 'wharness:chatgpt:external-auth', {
      cacheKey: chatGPTKeyForEntry(entry),
      provider: entry.externalAuthProvider,
      url: sanitizeDiagnosticURL(url || CHATGPT_LOGIN_URL),
      authMode: 'external',
      managedWindow: false,
      managedBrowser: true,
    })
  }
  publishChatGPTState(chatGPTKeyForEntry(entry))
}

function publishAuthComplete(cacheKey, mode, url) {
  const state = windowStateForEntry(chatgptViews.get(cacheKey))
  if (state) {
    sendToWindowState(state, 'wharness:chatgpt:auth-complete', {
      cacheKey,
      authMode: mode,
      url: sanitizeDiagnosticURL(url || CHATGPT_URL),
    })
  }
}

function publishAuthError(cacheKey, provider, message) {
  const state = windowStateForEntry(chatgptViews.get(cacheKey))
  if (state) {
    sendToWindowState(state, 'wharness:chatgpt:auth-error', {
      cacheKey,
      provider: provider || 'OpenAI',
      message: String(message || 'Falha na autenticação externa.'),
    })
  }
}

async function relayManagedBrowserCookies(cookies) {
  const chatSession = session.fromPartition(CHATGPT_PARTITION)
  let imported = 0
  for (const cookie of cookies || []) {
    const details = electronCookieDetails(cookie)
    if (!details) continue
    try {
      await chatSession.cookies.set(details)
      imported += 1
    } catch (error) {
      console.warn(`[chatgpt-auth] cookie relay skipped name=${details.name} error=${error instanceof Error ? error.message : String(error)}`)
    }
  }
  if (!imported) throw new Error('O navegador concluiu o login, mas nenhuma credencial ChatGPT pôde ser transferida para a sessão incorporada.')
  await chatSession.flushStorageData()
  return imported
}

async function cleanupManagedAuthentication(cacheKey, record) {
  if (chatGPTAuthBrowsers.get(cacheKey) === record) chatGPTAuthBrowsers.delete(cacheKey)
  await closeManagedBrowserAuth(record)
}

async function completeExternalAuthentication(cacheKey, entry, record, result) {
  if (record.completed || record.cancelled) return
  record.completed = true
  try {
    const imported = await relayManagedBrowserCookies(result.cookies)
    entry.externalAuthProvider = ''
    entry.authenticated = true
    const embedded = entry.view.webContents
    if (!embedded.isDestroyed()) {
      const current = embedded.getURL()
      const target = isTrustedChatGPTOrigin(current) && !isChatGPTAuthURL(current) ? current : CHATGPT_URL
      await embedded.loadURL(target, { userAgent: CHATGPT_USER_AGENT })
    }
    await cleanupManagedAuthentication(cacheKey, record)
    const ownerState = windowStateForEntry(entry)
    if (ownerState?.activeChatGPTKey === cacheKey) entry.view.setVisible(ownerState.chatgptVisible)
    publishChatGPTState(cacheKey)
    publishAuthComplete(cacheKey, 'external', result.callbackURL)
    console.log(`[chatgpt-auth] external callback completed key=${cacheKey} cookies=${imported} url=${sanitizeDiagnosticURL(result.callbackURL)}`)
  } catch (error) {
    await failExternalAuthentication(cacheKey, entry, record, error)
  }
}

async function failExternalAuthentication(cacheKey, entry, record, error) {
  if (record.cancelled) return
  record.cancelled = true
  entry.externalAuthProvider = ''
  await cleanupManagedAuthentication(cacheKey, record)
  const ownerState = windowStateForEntry(entry)
  if (ownerState?.activeChatGPTKey === cacheKey) entry.view.setVisible(ownerState.chatgptVisible)
  publishChatGPTState(cacheKey)
  const message = error instanceof Error ? error.message : String(error)
  publishAuthError(cacheKey, record.provider, message)
  console.error(`[chatgpt-auth] external failed key=${cacheKey} provider=${record.provider} error=${message}`)
}

function cancelExternalAuthentication(cacheKey) {
  const record = chatGPTAuthBrowsers.get(cacheKey)
  if (!record) return
  record.cancelled = true
  chatGPTAuthBrowsers.delete(cacheKey)
  void closeManagedBrowserAuth(record)
}

function startExternalAuthentication(entry, provider = 'OpenAI') {
  const cacheKey = chatGPTKeyForEntry(entry)
  if (!cacheKey) throw new Error('ChatGPT view is not registered')
  entry.authMode = 'external'
  const existing = chatGPTAuthBrowsers.get(cacheKey)
  if (existing && !existing.cancelled && !existing.completed) {
    publishExternalAuth(entry, provider, CHATGPT_LOGIN_URL)
    return { ok: true, cacheKey, reused: true }
  }

  const profileDir = managedAuthProfilePath()
  const activeRecord = [...chatGPTAuthBrowsers.entries()].find(([key, candidate]) => key !== cacheKey && !candidate.cancelled && !candidate.completed)
  if (activeRecord) throw new Error('Já existe uma autenticação externa em curso. Conclua ou cancele essa janela antes de iniciar outra.')
  const record = { completed: false, cancelled: false, provider, profileDir, port: 0, child: undefined }
  chatGPTAuthBrowsers.set(cacheKey, record)
  publishExternalAuth(entry, provider, CHATGPT_LOGIN_URL)
  console.log(`[chatgpt-auth] starting managed browser key=${cacheKey} provider=${provider} profile=persistent`)
  void launchManagedBrowserAuth({
    profileDir,
    loginURL: CHATGPT_LOGIN_URL,
    onReady: ({ port, child }) => {
      record.port = port
      record.child = child
      if (record.cancelled) void closeManagedBrowserAuth(record)
      publishChatGPTState(cacheKey)
    },
  }).then((result) => {
    record.port = result.port
    record.child = result.child
    if (record.cancelled) {
      void closeManagedBrowserAuth(record)
      return
    }
    void completeExternalAuthentication(cacheKey, entry, record, result)
  }).catch((error) => {
    if (record.cancelled) {
      void closeManagedBrowserAuth(record)
      return
    }
    void failExternalAuthentication(cacheKey, entry, record, error)
  })
  return { ok: true, cacheKey, reused: false }
}

function routeChatGPTNavigation(entry, event, url) {
  const disposition = chatGPTNavigationDisposition(url)
  if (disposition.kind === 'trusted') return false
  if (disposition.kind === 'chatgpt-auth' || disposition.kind === 'external-auth') {
    if (entry.authMode === 'embedded') {
      if (disposition.kind === 'external-auth' && disposition.provider === 'Google') {
        event?.preventDefault?.()
        entry.embeddedAuthActive = false
        entry.embeddedAuthCrossedBoundary = false
        startExternalAuthentication(entry, 'Google')
        return true
      }
      entry.externalAuthProvider = ''
      entry.embeddedAuthActive = true
      if (disposition.kind === 'external-auth') entry.embeddedAuthCrossedBoundary = true
      return false
    }
    event?.preventDefault?.()
    startExternalAuthentication(entry, disposition.provider || 'OpenAI')
    return true
  }
  event?.preventDefault?.()
  if (disposition.kind === 'external') void shell.openExternal(url)
  return true
}

function observeEmbeddedAuthURL(cacheKey, entry, url) {
  if (!entry.embeddedAuthActive) return
  const disposition = chatGPTNavigationDisposition(url)
  if (disposition.kind === 'external-auth') {
    entry.embeddedAuthCrossedBoundary = true
    return
  }
  if (disposition.kind === 'chatgpt-auth') return
  if (disposition.kind === 'trusted') {
    let pathname = ''
    try { pathname = new URL(url).pathname } catch { return }
    if (!entry.embeddedAuthCrossedBoundary && pathname !== '/') return
    entry.embeddedAuthActive = false
    entry.embeddedAuthCrossedBoundary = false
    publishAuthComplete(cacheKey, 'embedded', url)
    console.log(`[chatgpt-auth] embedded callback completed key=${cacheKey} url=${sanitizeDiagnosticURL(url)}`)
  }
}

function createChatGPTView(cacheKey, windowState) {
  if (!windowState?.window || windowState.window.isDestroyed()) throw new Error('Cannot create ChatGPT view without an owning Wharness window')
  const view = new WebContentsView({ webPreferences: securePreferences({ partition: CHATGPT_PARTITION }) })
  view.setBackgroundColor('#ffffff')
  view.setVisible(false)
  const entry = { ownerKey: cacheKey, ownerWindowId: windowState.id, view, loading: true, lastUsed: Date.now(), lastNetworkActivity: Date.now(), externalAuthProvider: '', authMode: 'external', embeddedAuthActive: false, embeddedAuthCrossedBoundary: false, authenticated: false, authProbeTimer: undefined, affinity: createChatGPTAffinityTracker() }
  chatgptViews.set(cacheKey, entry)
  windowState.window.contentView.addChildView(view)

  const wc = view.webContents
  wc.setUserAgent(CHATGPT_USER_AGENT)
  wc.setWindowOpenHandler(({ url }) => {
    const disposition = chatGPTNavigationDisposition(url)
    const embeddedProviderAllowed = entry.authMode === 'embedded' && disposition.kind === 'external-auth' && disposition.provider !== 'Google'
    if (entry.authMode === 'embedded' && (disposition.kind === 'chatgpt-auth' || embeddedProviderAllowed)) {
      void wc.loadURL(url, { userAgent: CHATGPT_USER_AGENT })
      return { action: 'deny' }
    }
    routeChatGPTNavigation(entry, undefined, url)
    return { action: 'deny' }
  })
  wc.on('will-navigate', (event, url) => { routeChatGPTNavigation(entry, event, url) })
  wc.on('will-redirect', (event, url) => { routeChatGPTNavigation(entry, event, url) })
  wc.on('did-start-loading', () => { entry.loading = true; touchChatGPTEntry(entry); publishChatGPTState(cacheKey) })
  wc.on('did-stop-loading', () => { entry.loading = false; observeChatGPTAffinityURL(cacheKey, entry, wc.getURL()); touchChatGPTEntry(entry); publishChatGPTState(cacheKey); scheduleEmbeddedChatGPTAuthenticationProbe(cacheKey, entry) })
  wc.on('did-navigate', (_event, url) => { observeEmbeddedAuthURL(cacheKey, entry, url); observeChatGPTAffinityURL(cacheKey, entry, url); touchChatGPTEntry(entry); publishChatGPTState(cacheKey); scheduleEmbeddedChatGPTAuthenticationProbe(cacheKey, entry) })
  wc.on('did-navigate-in-page', (_event, url) => { observeEmbeddedAuthURL(cacheKey, entry, url); observeChatGPTAffinityURL(cacheKey, entry, url); touchChatGPTEntry(entry); publishChatGPTState(cacheKey); scheduleEmbeddedChatGPTAuthenticationProbe(cacheKey, entry) })
  wc.on('page-title-updated', () => publishChatGPTState(cacheKey))
  wc.on('did-fail-load', (_event, code, description, url, isMainFrame) => {
    console.error(`[chatgpt-load] key=${cacheKey} code=${code} main=${Boolean(isMainFrame)} url=${sanitizeDiagnosticURL(url)} error=${description}`)
    if (isMainFrame && isRecoverableChatGPTNetworkError(description)) noteChatGPTRendererFault(cacheKey, description)
  })
  wc.on('render-process-gone', (_event, details) => {
    console.error(`[chatgpt-renderer] key=${cacheKey} gone reason=${details.reason} exitCode=${details.exitCode}`)
    noteChatGPTRendererFault(cacheKey, `renderer process gone: ${details.reason || 'unknown'}`)
  })
  wc.on('unresponsive', () => {
    console.error(`[chatgpt-renderer] key=${cacheKey} unresponsive`)
    noteChatGPTRendererFault(cacheKey, 'renderer unresponsive')
  })
  void wc.loadURL(CHATGPT_URL, { userAgent: CHATGPT_USER_AGENT })
  console.log(`[chatgpt-instance] created key=${cacheKey} wc=${wc.id}`)
  return entry
}

function ensureChatGPTView(cacheKey, windowState) {
  const key = sanitizeChatCacheKey(cacheKey)
  let entry = chatgptViews.get(key)
  if (!entry) entry = createChatGPTView(key, windowState)
  if (windowState && entry.ownerWindowId !== windowState.id) throw new Error('ChatGPT chat is already owned by another Wharness window')
  requireOwnedChatGPTEntry(key, entry)
  touchChatGPTEntry(entry)
  return { key, entry }
}

function activateChatGPTView(cacheKey, bounds, windowState) {
  const resolved = windowState || windowStateForEntry(chatgptViews.get(sanitizeChatCacheKey(cacheKey)))
  const { key, entry } = ensureChatGPTView(cacheKey, resolved)
  const ownerState = windowStateForEntry(entry)
  if (!ownerState) throw new Error('ChatGPT owner window is unavailable')
  const previous = activeChatGPTEntry(ownerState)
  if (previous && previous !== entry) previous.view.setVisible(false)
  ownerState.activeChatGPTKey = key
  if (bounds) setChatGPTBounds(bounds, ownerState)
  else if (ownerState.chatgptBounds) entry.view.setBounds(ownerState.chatgptBounds)
  entry.view.setVisible(ownerState.chatgptVisible && !entry.externalAuthProvider)
  touchChatGPTEntry(entry)
  publishChatGPTState(key)
  return entry
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

async function waitForConcreteChatGPTConversation(wc, fallback = '', timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs
  let candidate = ''
  let stableSince = 0
  while (Date.now() < deadline) {
    if (!wc || wc.isDestroyed()) break
    const current = canonicalChatGPTConversationURL(wc.getURL())
    if (current !== candidate) {
      candidate = current
      stableSince = current ? Date.now() : 0
    }
    if (candidate && !wc.isLoading() && Date.now() - stableSince >= 600) return candidate
    await wait(100)
  }
  const finalURL = !wc || wc.isDestroyed() ? '' : canonicalChatGPTConversationURL(wc.getURL())
  return finalURL || canonicalChatGPTConversationURL(fallback)
}

async function waitForSubmittedChatGPTConversation(cacheKey, entry, fallback = '') {
  const { wc } = requireOwnedChatGPTEntry(cacheKey, entry)
  const conversationURL = await waitForConcreteChatGPTConversation(wc, fallback, 30_000)
  if (conversationURL) settleChatGPTAffinityAfterSubmit(cacheKey, entry, conversationURL)
  return conversationURL
}

async function fetchContextZip(sessionId) {
  const id = sanitizeSessionId(sessionId)
  const response = await fetch(contextBundleURL(BACKEND_URL, id), { redirect: 'error' })
  if (!response.ok) throw new Error(`Context bundle HTTP ${response.status}`)
  const contentLength = Number(response.headers.get('content-length') || 0)
  if (contentLength > MAX_CONTEXT_BYTES) throw new Error('Context ZIP exceeds 256 MiB desktop limit')
  const bytes = Buffer.from(await response.arrayBuffer())
  if (bytes.byteLength > MAX_CONTEXT_BYTES) throw new Error('Context ZIP exceeds 256 MiB desktop limit')
  if (bytes.byteLength < 4 || bytes[0] !== 0x50 || bytes[1] !== 0x4b) throw new Error('Backend did not return a ZIP bundle')
  return { id, bytes }
}

async function publishRemoteChatInput(sessionId, requestId, prompt, includeContext, attachments, artifacts) {
  const id = sanitizeSessionId(sessionId)
  const target = new URL(`/api/sessions/${encodeURIComponent(id)}/remote-input`, BACKEND_URL)
  const response = await fetch(target, {
    method: 'POST', redirect: 'error', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(remoteInputPayload(requestId, prompt, includeContext, attachments, artifacts)),
  })
  const result = await response.json().catch(() => ({}))
  return parseRemoteInputResponse(response.status, result)
}

async function requireAutoSession(sessionId) {
  const id = sanitizeSessionId(sessionId)
  const target = new URL(`/api/sessions/${encodeURIComponent(id)}`, BACKEND_URL)
  const response = await fetch(target, { redirect: 'error' })
  if (!response.ok) throw new Error(`Session lookup HTTP ${response.status}`)
  const sessionState = await response.json()
  if (sessionState?.automation_mode !== 'auto') throw new Error('Automatic ChatGPT submission requires project Auto mode')
}

function decodeChatAttachmentSet(values) {
  if (!Array.isArray(values) || values.length > MAX_CHAT_ATTACHMENTS) throw new Error(`At most ${MAX_CHAT_ATTACHMENTS} chat attachments are allowed`)
  const decoded = values.map((value) => decodeUserAttachment(value, MAX_CHAT_ATTACHMENT_BYTES))
  const names = new Set()
  let total = 0
  for (const attachment of decoded) {
    const portableName = attachment.name.toLocaleLowerCase('en-US')
    if (names.has(portableName)) throw new Error(`Duplicate attachment filename: ${attachment.name}`)
    names.add(portableName)
    total += attachment.bytes.byteLength
  }
  if (total > MAX_CHAT_ATTACHMENTS_BYTES) throw new Error('Chat attachments exceed the 100 MiB total limit')
  return { decoded, total }
}

function decodeChatArtifactSet(values) {
  if (!Array.isArray(values) || values.length > MAX_CHAT_ARTIFACTS) throw new Error(`At most ${MAX_CHAT_ARTIFACTS} Wharness artifacts are allowed`)
  const decoded = values.map((value) => decodeUserAttachment(value, MAX_CHAT_ARTIFACT_BYTES))
  const names = new Set()
  let total = 0
  for (const artifact of decoded) {
    const portableName = artifact.name.toLocaleLowerCase('en-US')
    if (names.has(portableName)) throw new Error(`Duplicate Wharness artifact filename: ${artifact.name}`)
    names.add(portableName)
    total += artifact.bytes.byteLength
  }
  if (total > MAX_CHAT_ARTIFACTS_BYTES) throw new Error('Wharness artifacts exceed the 6 MiB total limit')
  return { decoded, total }
}

async function createPersistentAttachmentPreview(sourcePath, targetPath, mime, sourceBytes) {
  const safeRaster = SAFE_ATTACHMENT_IMAGE_MIMES.has(String(mime || '').toLowerCase()) && Number(sourceBytes || 0) <= MAX_ATTACHMENT_THUMBNAIL_SOURCE_BYTES
  let image = safeRaster ? nativeImage.createFromPath(sourcePath) : nativeImage.createEmpty()
  let kind = 'thumbnail'
  if (image.isEmpty()) {
    image = await app.getFileIcon(sourcePath, { size: 'large' })
    kind = 'icon'
  }
  if (image.isEmpty()) return 'none'
  const size = image.getSize()
  const scale = Math.min(1, 180 / Math.max(1, size.width), 120 / Math.max(1, size.height))
  if (scale < 1) image = image.resize({ width: Math.max(1, Math.round(size.width * scale)), height: Math.max(1, Math.round(size.height * scale)) })
  await writeFile(targetPath, image.toPNG(), { mode: 0o600 })
  return kind
}

function chatAttachmentRoot() {
  return path.join(app.getPath('userData'), 'chat-attachments-v1')
}

async function materializeChatInput(cacheKey, sessionId, values, artifactValues, promptText, includeContext) {
  const { decoded, total } = decodeChatAttachmentSet(values)
  const artifacts = decodeChatArtifactSet(artifactValues)
  const dir = path.join(app.getPath('temp'), 'wharness-chat-inputs', cacheKey)
  await rm(dir, { recursive: true, force: true })
  await mkdir(dir, { recursive: true, mode: 0o700 })
  const paths = []
  let contextBytes = 0
  if (includeContext) {
    const context = await fetchContextZip(sessionId)
    const contextPath = path.join(dir, `wharness-context-${context.id}.zip`)
    await writeFile(contextPath, context.bytes, { mode: 0o600 })
    paths.push(contextPath)
    contextBytes = context.bytes.byteLength
  }
  for (const artifact of artifacts.decoded) {
    const target = path.join(dir, artifact.name)
    await writeFile(target, artifact.bytes, { mode: 0o600, flag: 'wx' })
    paths.push(target)
  }
  for (const attachment of decoded) {
    const target = path.join(dir, attachment.name)
    await writeFile(target, attachment.bytes, { mode: 0o600, flag: 'wx' })
    paths.push(target)
  }
  const prompt = plannerPromptMarkdown(promptText)
  const promptDir = path.join(dir, 'prompt')
  await mkdir(promptDir, { recursive: true, mode: 0o700 })
  const promptPath = path.join(promptDir, prompt.name)
  await writeFile(promptPath, prompt.bytes, { mode: 0o600, flag: 'wx' })
  return { paths, promptPath, userAttachmentCount: decoded.length, artifactCount: artifacts.decoded.length, bytes: contextBytes + total + artifacts.total + prompt.bytes.byteLength }
}


async function materializeCommentAttachments(cacheKey, values) {
  const { decoded, total } = decodeChatAttachmentSet(values)
  if (!decoded.length) return { paths: [], bytes: 0 }
  const dir = path.join(app.getPath('temp'), 'wharness-chat-comments', cacheKey, `${Date.now()}`)
  await mkdir(dir, { recursive: true, mode: 0o700 })
  const paths = []
  for (const attachment of decoded) {
    const target = path.join(dir, attachment.name)
    await writeFile(target, attachment.bytes, { mode: 0o600, flag: 'wx' })
    paths.push(target)
  }
  return { paths, bytes: total }
}

async function targetChatGPTComposer(cacheKey, expectedURL = '', preferCurrentConversation = false) {
  const key = sanitizeChatCacheKey(cacheKey)
  const { entry } = ensureChatGPTView(key)
  const { wc } = requireOwnedChatGPTEntry(key, entry)
  if (entry.externalAuthProvider) throw new Error(`ChatGPT está em autenticação externa via ${entry.externalAuthProvider}. Use o navegador do sistema e importe o bundle ZIP pelo Wharness.`)
  if (expectedURL) {
    const target = requireTrustedChatGPTURL(expectedURL)
    const linkedConversation = canonicalChatGPTConversationURL(target)
    if (linkedConversation && entry.affinity.boundURL !== linkedConversation && entry.affinity.phase !== 'candidate') syncChatGPTAffinityURL(key, entry, linkedConversation)
    const currentConversation = canonicalChatGPTConversationURL(wc.getURL())
    const keepCurrent = preferCurrentConversation && Boolean(currentConversation)
    if (!sameConversationURL(wc.getURL(), target) && !keepCurrent) await wc.loadURL(target, { userAgent: CHATGPT_USER_AGENT })
    else if (keepCurrent) proposeCurrentChatGPTAffinity(key, entry, linkedConversation, currentConversation)
  }
  await waitForChatGPTSurfaceReady(key, entry)
  const focused = await wc.executeJavaScript(chatGPTFocusComposerScript(), true)
  if (!focused) throw new Error('ChatGPT composer DOM was not found')
  touchChatGPTEntry(entry)
  return { key, entry, wc, conversationUrl: canonicalChatGPTConversationURL(wc.getURL()) }
}

async function waitForChatGPTSurfaceReady(cacheKey, entry) {
  const { wc } = requireOwnedChatGPTEntry(cacheKey, entry)
  await waitForChatGPTReady({
    isLoading: () => entry.loading || wc.isLoading(),
    lastNetworkActivity: () => entry.lastNetworkActivity,
    wait,
  })
  if (!isTrustedChatGPTOrigin(wc.getURL())) throw new Error('Active cached view is not a trusted ChatGPT page')
}

async function pasteChatGPTFile(entry, filePath, index, count) {
  const key = chatGPTKeyForEntry(entry)
  const { wc } = requireOwnedChatGPTEntry(key, entry)
  const result = await pasteWithUploadRetry({
    beforeAttempt: async () => {
      await waitForChatGPTSurfaceReady(key, entry)
      const focused = await wc.executeJavaScript(chatGPTFocusComposerScript(), true)
      if (!focused) throw new Error('ChatGPT composer DOM was not found before upload')
    },
    beginUpload: () => chatGPTUploads.expect(wc.id),
    paste: async () => {
      await clipboard.write([new ClipboardItem({ 'text/uri-list': `${pathToFileURL(filePath).href}\r\n` })])
      wc.paste()
    },
    onRetry: ({ attempt, error }) => {
      console.warn(`[chatgpt-upload] retry wc=${wc.id} file=${index}/${count} failedAttempt=${attempt} error=${error.message}`)
    },
  })
  console.log(`[chatgpt-upload] confirmed wc=${wc.id} file=${index}/${count} observed=${result.observed}`)
}

async function submitChatGPTDraft(key) {
  const target = await targetChatGPTComposer(key)
  const wc = target.wc
  markChatGPTAffinitySubmitted(target.entry.affinity)
  const observed = chatGPTSubmissions.expect(wc.id)
  const clicked = await wc.executeJavaScript(chatGPTSubmitScript(), true)
  if (!clicked) dispatchChatGPTSubmit(wc)
  try {
    const result = await observed
    console.log(`[chatgpt-submit] accepted key=${key} method=${clicked ? 'dom-click' : 'native-enter'} request=${result.requestId}`)
    return result
  } catch (error) {
    const observationError = error instanceof Error ? error.message : String(error)
    console.warn(`[chatgpt-submit] dispatched-unconfirmed key=${key} method=${clicked ? 'dom-click' : 'native-enter'} observation=${observationError}`)
    return { accepted: false, requestId: '', observationError }
  }
}

async function preparePromptForChatGPT(request) {
  const text = String(request?.text || '').trim()
  if (!text) throw new Error('Prepared prompt is empty')
  if (text.length > 1024 * 1024) throw new Error('Prepared prompt exceeds 1 MiB limit')
  const key = sanitizeChatCacheKey(request?.cacheKey)
  const requestId = String(request?.requestId || '').trim()
  const expectedFilename = canonicalBundleFilename(requestId)
  const autoSubmit = request?.autoSubmit === true
  if (autoSubmit) await requireAutoSession(request?.sessionId)
  const linkedConversation = canonicalChatGPTConversationURL(request?.url || '')
  const target = await targetChatGPTComposer(key, linkedConversation || CHATGPT_URL, linkedConversation ? request?.preferCurrentConversation === true : false)
  if (!linkedConversation) syncChatGPTAffinityURL(key, target.entry)
  const currentSha = String(request?.contextSha256 || '').trim()
  const previousSha = String(request?.lastContextSha256 || '').trim()
  const previousURL = String(request?.lastContextChatgptUrl || '').trim()
  const includeContext = shouldAttachProjectContext({ currentSha, previousSha, currentConversationId: chatGPTConversationID(target.conversationUrl), previousConversationId: chatGPTConversationID(previousURL), force: request?.includeContext === true })

  const remoteInput = await publishRemoteChatInput(request?.sessionId, requestId, text, includeContext, request?.attachments || [], request?.artifacts || [])
  if (remoteInput) {
    const filled = await target.wc.executeJavaScript(chatGPTFillComposerScript(remoteInput.bootstrapPrompt), true)
    if (!filled) throw new Error('ChatGPT composer DOM could not be populated with remote input bootstrap')
    let conversationUrl = target.conversationUrl
    if (autoSubmit) {
      const assistantBaseline = await chatGPTAssistantTurnCount(target.wc)
      await wait(250)
      await submitChatGPTDraft(key)
      armExpectedChatGPTBundle(key, requestId, assistantBaseline, remoteInput.bootstrapPrompt)
      conversationUrl = await waitForSubmittedChatGPTConversation(key, target.entry, target.conversationUrl)
      preparedChatGPTDrafts.delete(key)
    } else {
      preparedChatGPTDrafts.set(key, { preparedAt: Date.now(), attachmentCount: 0, requestId, recoveryBootstrap: remoteInput.bootstrapPrompt })
    }
    touchChatGPTEntry(target.entry)
    console.log(`[chatgpt-draft] prepared key=${key} transport=remote provider=${String(remoteInput.provider || 'configured')} instance=${String(remoteInput.instance_id || 'configured')} bytes=${Number(remoteInput.bytes || 0)} chars=${remoteInput.bootstrapPrompt.length} autoSubmit=${autoSubmit}`)
    return { ok: true, cacheKey: key, attachmentCount: 1, submitted: autoSubmit, expectedFilename, includedContext: includeContext, conversationUrl, transport: 'remote_url', provider: remoteInput.provider, instanceId: remoteInput.instance_id, expiresAt: remoteInput.expires_at }
  }

  const input = await materializeChatInput(key, request?.sessionId, request?.attachments || [], request?.artifacts || [], text, includeContext)
  const transportPaths = [...input.paths, input.promptPath]
  for (let index = 0; index < transportPaths.length; index += 1) {
    await pasteChatGPTFile(target.entry, transportPaths[index], index + 1, transportPaths.length)
  }
  let conversationUrl = target.conversationUrl
  if (autoSubmit) {
    await wait(chatInputSettleDelay(input.bytes, transportPaths.length))
    const assistantBaseline = await chatGPTAssistantTurnCount(target.wc)
    await submitChatGPTDraft(key)
    armExpectedChatGPTBundle(key, requestId, assistantBaseline)
    conversationUrl = await waitForSubmittedChatGPTConversation(key, target.entry, target.conversationUrl)
    preparedChatGPTDrafts.delete(key)
  } else {
    preparedChatGPTDrafts.set(key, { preparedAt: Date.now(), attachmentCount: transportPaths.length, requestId })
  }
  touchChatGPTEntry(target.entry)
  console.log(`[chatgpt-draft] prepared key=${key} attachments=${transportPaths.length} systemArtifacts=${input.artifactCount} includeContext=${includeContext} bytes=${input.bytes} chars=${text.length} autoSubmit=${autoSubmit}`)
  return { ok: true, cacheKey: key, attachmentCount: transportPaths.length, submitted: autoSubmit, expectedFilename, includedContext: includeContext, conversationUrl }
}

async function attachContextToChatGPT(request) {
  const key = sanitizeChatCacheKey(request?.cacheKey)
  const target = await targetChatGPTComposer(key, request?.url || '', true)
  const context = await fetchContextZip(request?.sessionId)
  const dir = path.join(app.getPath('temp'), 'wharness-chat-inputs', key, 'manual-context')
  await rm(dir, { recursive: true, force: true })
  await mkdir(dir, { recursive: true, mode: 0o700 })
  const filePath = path.join(dir, `wharness-context-${context.id}.zip`)
  await writeFile(filePath, context.bytes, { mode: 0o600 })
  await pasteChatGPTFile(target.entry, filePath, 1, 1)
  await wait(chatInputSettleDelay(context.bytes.byteLength, 1))
  const submission = await submitChatGPTDraft(key)
  if (!submission.accepted) throw new Error('ChatGPT context submission was dispatched but could not be confirmed')
  const conversationUrl = await waitForSubmittedChatGPTConversation(key, target.entry, target.conversationUrl)
  touchChatGPTEntry(target.entry)
  return { ok: true, cacheKey: key, bytes: context.bytes.byteLength, submitted: true, conversationUrl }
}

async function attachPromptToChatGPT(request) {
  const text = String(request?.text || '').trim()
  if (!text) throw new Error('Prepared prompt is empty')
  if (text.length > 1024 * 1024) throw new Error('Prepared prompt exceeds 1 MiB limit')
  const key = sanitizeChatCacheKey(request?.cacheKey)
  const target = await targetChatGPTComposer(key, request?.url || '', true)
  const prompt = plannerPromptMarkdown(text)
  const dir = path.join(app.getPath('temp'), 'wharness-chat-inputs', key, 'manual-prompt')
  await rm(dir, { recursive: true, force: true })
  await mkdir(dir, { recursive: true, mode: 0o700 })
  const filePath = path.join(dir, prompt.name)
  await writeFile(filePath, prompt.bytes, { mode: 0o600 })
  await pasteChatGPTFile(target.entry, filePath, 1, 1)
  await wait(chatInputSettleDelay(prompt.bytes.byteLength, 1))
  const submission = await submitChatGPTDraft(key)
  if (!submission.accepted) throw new Error('ChatGPT prompt submission was dispatched but could not be confirmed')
  const conversationUrl = await waitForSubmittedChatGPTConversation(key, target.entry, target.conversationUrl)
  touchChatGPTEntry(target.entry)
  return { ok: true, cacheKey: key, bytes: prompt.bytes.byteLength, submitted: true, conversationUrl }
}

async function submitPreparedChatGPTDraft(cacheKey) {
  const key = sanitizeChatCacheKey(cacheKey)
  const prepared = preparedChatGPTDrafts.get(key)
  if (!prepared || Date.now() - prepared.preparedAt > 10 * 60 * 1000) throw new Error('No recent prepared ChatGPT draft exists for this chat')
  const entry = activateChatGPTView(key)
  const assistantBaseline = await chatGPTAssistantTurnCount(entry.view.webContents)
  await submitChatGPTDraft(key)
  const expectedFilename = armExpectedChatGPTBundle(key, prepared.requestId, assistantBaseline, prepared.recoveryBootstrap)
  const conversationUrl = await waitForSubmittedChatGPTConversation(key, entry)
  preparedChatGPTDrafts.delete(key)
  touchChatGPTEntry(entry)
  return { ok: true, cacheKey: key, expectedFilename, conversationUrl }
}

async function submitPromptToChatGPT(cacheKey, value, expectedURL = '', requestId = '') {
  const text = String(value || '').trim()
  if (!text) throw new Error('Repair prompt is empty')
  if (text.length > 1024 * 1024) throw new Error('Repair prompt exceeds 1 MiB limit')

  const key = sanitizeChatCacheKey(cacheKey)
  const expectedFilename = canonicalBundleFilename(requestId)
  const target = await targetChatGPTComposer(key, expectedURL)
  const assistantBaseline = await chatGPTAssistantTurnCount(target.wc)
  const filled = await target.wc.executeJavaScript(chatGPTFillComposerScript(text), true)
  if (!filled) throw new Error('ChatGPT composer DOM could not be populated')
  await wait(100)
  await submitChatGPTDraft(key)
  armExpectedChatGPTBundle(key, requestId, assistantBaseline)
  await waitForSubmittedChatGPTConversation(key, target.entry, target.conversationUrl)
  touchChatGPTEntry(target.entry)
  console.log(`[chatgpt-repair] submitted key=${key} chars=${text.length} method=dom`)
  return { ok: true, cacheKey: key, expectedFilename }
}


function chatGPTCommentFingerprint(key, requestId, comment, attachments = []) {
  const attachmentSignature = attachments.map((item) => [item?.name, item?.size, item?.type || item?.mime].map((value) => String(value || '')).join(':')).join('|')
  return createHash('sha256').update(`${key}\0${requestId}\0${comment}\0${attachmentSignature}`).digest('hex')
}

async function queueChatGPTComment(request) {
  const key = sanitizeChatCacheKey(request?.cacheKey)
  const requestId = String(request?.requestId || '').trim()
  const comment = String(request?.text || '').trim()
  if (!comment) throw new Error('Task comment is empty')
  if (comment.length > 16_000) throw new Error('Task comment exceeds 16 KiB limit')
  const expectedFilename = canonicalBundleFilename(requestId)
  const text = `USER COMMENT FOR THE ACTIVE WHARNESS TASK:
${comment}

Treat this as additional guidance for the SAME task and SAME request. Do not replace, cancel or downgrade the original deliverable. Continue the work and still return the required canonical bundle ${expectedFilename}.`
  const commentId = String(request?.commentId || `${requestId}:${comment}`).slice(0, 20000)
  const attachments = Array.isArray(request?.attachments) ? request.attachments : []
  const fingerprint = chatGPTCommentFingerprint(key, requestId, comment, attachments)
  const now = Date.now()
  const priorAt = recentChatGPTCommentIds.get(`${key}:${commentId}`) || 0
  const priorFingerprintAt = recentChatGPTCommentFingerprints.get(fingerprint) || 0
  if (now - priorAt < 30 * 60 * 1000 || now - priorFingerprintAt < 60 * 1000) return { ok: true, cacheKey: key, queued: hasPendingChatGPTComments(key), requestId, duplicate: true }
  const queue = pendingChatGPTComments.get(key) || []
  if (!queue.some((item) => item.commentId === commentId || item.fingerprint === fingerprint)) queue.push({ commentId, fingerprint, text, url: String(request?.url || ''), requestId, attachments, queuedAt: now })
  pendingChatGPTComments.set(key, queue)
  await flushQueuedChatGPTComments()
  return { ok: true, cacheKey: key, queued: Boolean(pendingChatGPTComments.get(key)?.length), requestId }
}

function hasPendingChatGPTComments(key) {
  return Boolean(pendingChatGPTComments.get(key)?.length)
}

async function flushQueuedChatGPTComments() {
  for (const [key, queue] of pendingChatGPTComments) {
    while (queue.length && Date.now() - queue[0].queuedAt > 30 * 60 * 1000) queue.shift()
    if (!queue.length) { pendingChatGPTComments.delete(key); continue }
    if (flushingChatGPTComments.has(key)) continue
    flushingChatGPTComments.add(key)
    const pending = queue[0]
    try {
      const target = await targetChatGPTComposer(key, pending.url, true)
      const ready = await target.wc.executeJavaScript(chatGPTComposerReadyScript(), true)
      if (!ready) continue
      const attachmentSet = await materializeCommentAttachments(key, pending.attachments)
      for (let index = 0; index < attachmentSet.paths.length; index += 1) await pasteChatGPTFile(target.entry, attachmentSet.paths[index], index + 1, attachmentSet.paths.length)
      const filled = await target.wc.executeJavaScript(chatGPTFillComposerScript(pending.text), true)
      if (!filled) continue
      const assistantBaseline = await chatGPTAssistantTurnCount(target.wc)
      await wait(80)
      await submitChatGPTDraft(key)
      queue.shift()
      recentChatGPTCommentIds.set(`${key}:${pending.commentId}`, Date.now())
      recentChatGPTCommentFingerprints.set(pending.fingerprint, Date.now())
      if (!queue.length) pendingChatGPTComments.delete(key)
      if (expectedChatGPTBundles.has(key)) armExpectedChatGPTBundle(key, pending.requestId, assistantBaseline)
      touchChatGPTEntry(target.entry)
      sendToChatGPTKey(key, 'wharness:chatgpt:comment-sent', { cacheKey: key, requestId: pending.requestId, attachments: attachmentSet.paths.length })
      break
    } catch (error) {
      console.warn(`[chatgpt-comment] queued key=${key} error=${error instanceof Error ? error.message : String(error)}`)
    } finally {
      flushingChatGPTComments.delete(key)
      const cutoff = Date.now() - 30 * 60 * 1000
      const fingerprintCutoff = Date.now() - 60 * 1000
      for (const [id, sentAt] of recentChatGPTCommentIds) if (sentAt < cutoff) recentChatGPTCommentIds.delete(id)
      for (const [fingerprint, sentAt] of recentChatGPTCommentFingerprints) if (sentAt < fingerprintCutoff) recentChatGPTCommentFingerprints.delete(fingerprint)
    }
  }
}

async function pollChatGPTVisibleActivity() {
  for (const [key, entry] of chatgptViews) {
    const wc = entry.view.webContents
    if (wc.isDestroyed() || !isTrustedChatGPTOrigin(wc.getURL())) continue
    try {
      const activity = await wc.executeJavaScript(chatGPTVisibleActivityScript(), true)
      const normalized = { cacheKey: key, state: activity?.state === 'thinking' ? 'thinking' : 'idle', text: String(activity?.text || '').trim(), capturedAt: String(activity?.capturedAt || new Date().toISOString()) }
      const fingerprint = `${normalized.state}:${normalized.text}`
      if (chatGPTActivityFingerprints.get(key) === fingerprint) continue
      chatGPTActivityFingerprints.set(key, fingerprint)
      const expected = expectedChatGPTBundles.get(key)
      if (expected?.recovery) noteChatGPTRecoveryProgress(expected.recovery, `activity:${fingerprint}`, Date.now())
      sendToChatGPTKey(key, 'wharness:chatgpt:activity', normalized)
    } catch { /* best-effort visible DOM telemetry */ }
  }
}

async function performChatGPTRecoveryAction(key, expected, entry, action, completion = {}) {
  if (!action || !expected?.recovery) return false
  const { wc } = requireOwnedChatGPTEntry(key, entry)
  const now = Date.now()
  if (action.type === 'reload') {
    commitChatGPTRecoveryAction(expected.recovery, action, now)
    expected.settledAt = 0
    expected.lastDOMClick = 0
    console.warn(`[chatgpt-recovery] reload key=${key} request=${expected.requestId} reason=${action.reason} attempt=${expected.recovery.reloadCount}`)
    wc.reload()
    const text = action.reason === 'transport'
      ? 'Falha de ligação detetada no ChatGPT. A conversa foi recarregada automaticamente para re-hidratar o processamento.'
      : action.reason === 'stalled'
        ? 'O processamento do ChatGPT parece ter parado. A conversa foi recarregada uma vez para recuperar atualizações pendentes.'
        : action.reason === 'silent'
          ? 'O ChatGPT deixou de mostrar processamento sem produzir nova resposta. A conversa foi recarregada uma vez para recuperar o pedido.'
          : 'A resposta terminou sem o bundle esperado. A conversa foi recarregada uma vez antes da continuação automática.'
    sendToChatGPTKey(key, 'wharness:chatgpt:activity', { cacheKey: key, state: 'thinking', text, capturedAt: new Date().toISOString() })
    return true
  }
  if (action.type !== 'prompt') return false
  const prompt = chatGPTStalledRecoveryPrompt(expected.requestId, expected.filename, expected.recoveryBootstrap)
  const filled = await wc.executeJavaScript(chatGPTFillComposerScript(prompt), true)
  if (!filled) return false
  await wait(80)
  const submission = await submitChatGPTDraft(key)
  commitChatGPTRecoveryAction(expected.recovery, action, now)
  expected.assistantBaseline = Math.max(expected.assistantBaseline, Number(completion?.assistantCount) || 0)
  expected.settledAt = 0
  expected.lastDOMClick = 0
  console.warn(`[chatgpt-recovery] prompt key=${key} request=${expected.requestId} accepted=${Boolean(submission?.accepted)}`)
  sendToChatGPTKey(key, 'wharness:chatgpt:activity', { cacheKey: key, state: 'thinking', text: 'O ChatGPT continuou parado após a recarga. O Wharness enviou uma instrução automática para retomar o pedido original e concluir a entrega.', capturedAt: new Date().toISOString() })
  return true
}

async function pollExpectedChatGPTDownloads() {
  const now = Date.now()
  for (const [key, expected] of expectedChatGPTBundles) {
    if (hasPendingChatGPTComments(key)) continue
    if (now - expected.armedAt > EXPECTED_BUNDLE_TTL_MS) {
      expectedChatGPTBundles.delete(key)
      sendToChatGPTKey(key, 'wharness:chatgpt:bundle-download-error', { cacheKey: key, requestId: expected.requestId, error: 'Tempo limite excedido enquanto o Wharness aguardava o bundle canónico.' })
      continue
    }
    const entry = chatgptViews.get(key)
    const wc = entry?.view.webContents
    if (!entry || wc?.isDestroyed() || !isTrustedChatGPTOrigin(wc.getURL())) continue
    try {
      const faultAction = chooseChatGPTRecoveryAction(expected.recovery, {}, now)
      if (faultAction?.reason === 'transport') {
        await performChatGPTRecoveryAction(key, expected, entry, faultAction)
        break
      }
      if (entry.loading) continue

      if (!expected.lastDOMClick || now - expected.lastDOMClick >= DOM_DOWNLOAD_RETRY_MS) {
        const clickMode = await wc.executeJavaScript(chatGPTExpectedDownloadScript(expected.filename, expected.assistantBaseline), true)
        if (clickMode) {
          expected.lastDOMClick = now
          recentExpectedDownload = { key, requestId: expected.requestId, at: now }
          console.log(`[chatgpt-bundle-dom] download-triggered key=${key} file=${expected.filename} mode=${clickMode}`)
          break
        }
      }

      const completion = await wc.executeJavaScript(chatGPTResponseCompletionScript(expected.assistantBaseline), true)
      noteChatGPTRecoveryAssistantCount(expected.recovery, completion?.assistantCount, now)
      const responseStarted = Number(completion?.assistantCount || 0) > Number(expected.assistantBaseline || 0)
      if (!completion?.complete) expected.settledAt = 0
      else if (!expected.settledAt) expected.settledAt = now
      const completionSettled = completion?.complete === true
        && Boolean(expected.settledAt)
        && now - expected.settledAt >= BUNDLE_COMPLETION_GRACE_MS
      const recoveryAction = chooseChatGPTRecoveryAction(expected.recovery, {
        complete: completionSettled,
        thinking: completion?.thinking === true,
        responseStarted,
      }, now)
      if (recoveryAction) {
        await performChatGPTRecoveryAction(key, expected, entry, recoveryAction, completion)
        break
      }

      if (!completion?.complete || !completionSettled) continue
      const continuationDelay = Math.min(30_000, BUNDLE_CONTINUATION_BASE_MS + Number(expected.continuationCount || 0) * 3_000)
      if (expected.lastContinuationAt && now - expected.lastContinuationAt < continuationDelay) continue

      const continuation = `WHARNESS DELIVERY CONTINUATION — SAME REQUEST ${expected.requestId}

The previous ChatGPT turn finished without a detected validated downloadable bundle named ${expected.filename}.
Do not restart the analysis, change scope, or answer with prose. Continue from the work already completed and create/attach exactly ${expected.filename} according to the existing Wharness file-first contract. Finish with the file attachment only.`
      const filled = await wc.executeJavaScript(chatGPTFillComposerScript(continuation), true)
      if (!filled) continue
      await wait(80)
      await submitChatGPTDraft(key)
      expected.assistantBaseline = Math.max(expected.assistantBaseline, Number(completion.assistantCount) || 0)
      expected.continuationCount = Number(expected.continuationCount || 0) + 1
      expected.lastContinuationAt = now
      expected.settledAt = 0
      expected.lastDOMClick = 0
      expected.recovery = createChatGPTRecoveryState(now)
      console.log(`[chatgpt-bundle-dom] continuation-submitted key=${key} request=${expected.requestId} attempt=${expected.continuationCount}`)
      sendToChatGPTKey(key, 'wharness:chatgpt:activity', { cacheKey: key, state: 'thinking', text: `Bundle não detetado após a resposta. Continuação automática ${expected.continuationCount} enviada para preservar o objetivo.`, capturedAt: new Date().toISOString() })
      break
    } catch (error) {
      console.warn(`[chatgpt-bundle-dom] scan-failed key=${key} error=${error instanceof Error ? error.message : String(error)}`)
    }
  }
}

async function exportBrowserSession(windowState) {
  const chatSession = session.fromPartition(CHATGPT_PARTITION)
  await chatSession.flushStorageData()
  closeAllChatGPTViews()
  const snapshot = await snapshotBrowserSession(chatGPTPartitionPath())
  const result = await dialog.showSaveDialog(windowState?.window, {
    title: 'Exportar sessão do navegador Wharness',
    defaultPath: path.join(app.getPath('downloads'), `wharness-browser-session-${new Date().toISOString().slice(0, 10)}.whbs`),
    filters: [{ name: 'Wharness Browser Session', extensions: ['whbs'] }],
  })
  if (result.canceled || !result.filePath) return { cancelled: true }
  await writeFile(result.filePath, snapshot, { mode: 0o600 })
  return { cancelled: false, bytes: snapshot.byteLength, filename: path.basename(result.filePath) }
}

async function importBrowserSession(windowState) {
  const result = await dialog.showOpenDialog(windowState?.window, {
    title: 'Importar sessão do navegador Wharness',
    defaultPath: app.getPath('downloads'),
    properties: ['openFile'],
    filters: [{ name: 'Wharness Browser Session', extensions: ['whbs'] }],
  })
  if (result.canceled || result.filePaths.length === 0) return { cancelled: true }
  const raw = await readFile(result.filePaths[0])
  const validationRoot = path.join(app.getPath('temp'), `wharness-browser-import-${process.pid}`)
  const restored = await restoreBrowserSession(validationRoot, raw)
  await rm(validationRoot, { recursive: true, force: true })
  await writeFile(pendingBrowserImportPath(), raw, { mode: 0o600 })
  closeAllChatGPTViews()
  setTimeout(() => { app.relaunch(); app.exit(0) }, 500)
  return { cancelled: false, restarting: true, ...restored }
}

async function applyPendingBrowserSessionImport() {
  let raw
  try { raw = await readFile(pendingBrowserImportPath()) } catch { return false }
  await restoreBrowserSession(chatGPTPartitionPath(), raw)
  await rm(pendingBrowserImportPath(), { force: true })
  console.log('[chatgpt-session] imported browser session before partition startup')
  return true
}

async function clearBrowserSession() {
  const authRecords = [...chatGPTAuthBrowsers.values()]
  closeAllChatGPTViews()
  for (const record of authRecords) await closeManagedBrowserAuth(record)
  preparedChatGPTDrafts.clear()
  expectedChatGPTBundles.clear()
  recentExpectedDownload = undefined
  const chatSession = session.fromPartition(CHATGPT_PARTITION)
  await chatSession.clearStorageData()
  await chatSession.clearCache()
  await chatSession.flushStorageData()
  await rm(managedAuthProfilePath(), { recursive: true, force: true, maxRetries: 5, retryDelay: 100 })
  return { ok: true }
}

async function desktopStorageUsage() {
  const userData = app.getPath('userData')
  const embeddedBrowserBytes = await pathSize(chatGPTPartitionPath())
  const managedBrowserBytes = await pathSize(managedAuthProfilePath())
  const browserBytes = embeddedBrowserBytes + managedBrowserBytes
  const attachmentBytes = await pathSize(chatAttachmentRoot())
  let tempBytes = 0
  let entries = []
  try { entries = await readdir(app.getPath('temp'), { withFileTypes: true }) } catch { /* best effort */ }
  for (const entry of entries) {
    if (!entry.isDirectory() || !/^(wharness-(bundles|plans|context|chat-inputs))$/.test(entry.name)) continue
    tempBytes += await pathSize(path.join(app.getPath('temp'), entry.name))
  }
  const userDataBytes = await pathSize(userData)
  return { total_bytes: userDataBytes + tempBytes, user_data_bytes: userDataBytes, browser_bytes: browserBytes, attachment_bytes: attachmentBytes, temp_bytes: tempBytes, other_user_data_bytes: Math.max(0, userDataBytes - browserBytes - attachmentBytes) }
}

async function clearDesktopWharnessData() {
  await clearBrowserSession()
  const localSession = session.defaultSession
  await localSession.clearStorageData()
  await localSession.clearCache()
  await localSession.flushStorageData()
  await rm(chatAttachmentRoot(), { recursive: true, force: true })
  await rm(pendingBrowserImportPath(), { force: true })
  for (const name of ['wharness-bundles', 'wharness-plans', 'wharness-context', 'wharness-chat-inputs']) {
    await rm(path.join(app.getPath('temp'), name), { recursive: true, force: true })
  }
  return { ok: true }
}

function chatGPTConversationID(value) {
  try {
    const trusted = requireTrustedChatGPTURL(value)
    return /^\/c\/([^/]+)/.exec(new URL(trusted).pathname)?.[1] || ''
  } catch { return '' }
}

function canonicalChatGPTConversationURL(value) {
  const id = chatGPTConversationID(value)
  return id ? `https://chatgpt.com/c/${id}` : ''
}

function sameConversationURL(left, right) {
  const a = chatGPTConversationID(left)
  const b = chatGPTConversationID(right)
  return Boolean(a && b && a === b)
}

function createWindow(windowId = `window-${randomUUID()}`, persistLayout = true) {
  const id = /^[A-Za-z0-9_-]{1,80}$/.test(String(windowId || '')) ? String(windowId) : `window-${randomUUID()}`
  const win = new BrowserWindow({
    width: 1540,
    height: 960,
    minWidth: 1100,
    minHeight: 720,
    title: 'Wharness Desktop',
    name: `wharness-${id}`,
    windowStatePersistence: true,
    backgroundColor: '#eceee7',
    autoHideMenuBar: true,
    webPreferences: securePreferences({ preload: path.join(here, 'preload.cjs') }),
  })
  const state = { id, window: win, projects: new Set(), activeChatGPTKey: '', chatgptVisible: false, chatgptBounds: undefined }
  desktopWindows.set(id, state)
  mainWindow = win

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (isHTTPS(url)) void shell.openExternal(url)
    return { action: 'deny' }
  })
  win.webContents.on('will-navigate', (event, url) => {
    try { if (new URL(url).origin !== FRONTEND_ORIGIN) event.preventDefault() }
    catch { event.preventDefault() }
  })
  win.on('focus', () => { mainWindow = win; publishChatGPTState(state.activeChatGPTKey) })
  win.on('blur', () => publishChatGPTState(state.activeChatGPTKey))
  win.on('closed', () => {
    closeChatGPTViewsForWindow(state)
    releaseWindowProjects(state)
    desktopWindows.delete(id)
    if (mainWindow === win) mainWindow = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0]
    if (!quitting) persistWindowLayout()
  })

  const target = new URL(FRONTEND_URL)
  target.searchParams.set('wharnessWindow', id)
  void win.loadURL(target.href)
  if (!quitting && persistLayout) persistWindowLayout()
  return state
}

function registerIPC() {
  ipcMain.handle('wharness:projects:pick-directory', async (event, request) => {
    const windowState = trustedSender(event)
    const result = await dialog.showOpenDialog(windowState.window, {
      title: typeof request?.title === 'string' ? request.title.slice(0, 120) : 'Selecionar pasta',
      defaultPath: typeof request?.defaultPath === 'string' && path.isAbsolute(request.defaultPath) ? request.defaultPath : undefined,
      properties: ['openDirectory', 'createDirectory'],
    })
    return { cancelled: result.canceled || result.filePaths.length === 0, path: result.filePaths[0] || '' }
  })
  ipcMain.handle('wharness:projects:acquire', (event, request) => acquireProjectForWindow(trustedSender(event), request?.projectPath))
  ipcMain.handle('wharness:projects:release', (event, request) => releaseProjectForWindow(trustedSender(event), request?.projectPath))
  ipcMain.handle('wharness:projects:bindings', (event) => {
    const windowState = trustedSender(event)
    return { windowId: windowState.id, projects: [...windowState.projects] }
  })
  ipcMain.handle('wharness:windows:info', (event) => {
    const windowState = trustedSender(event)
    return { windowId: windowState.id, windowCount: desktopWindows.size }
  })
  ipcMain.handle('wharness:windows:open', (event) => {
    trustedSender(event)
    const windowState = createWindow()
    windowState.window.show(); windowState.window.focus()
    return { ok: true, windowId: windowState.id }
  })
  ipcMain.handle('wharness:windows:prepare-restart', (event, request) => {
    const windowState = trustedSender(event)
    const scope = request?.scope === 'current' ? 'current' : 'all'
    persistWindowLayout()
    persistRestartIntent(scope, windowState.id)
    for (const state of desktopWindows.values()) {
      sendToWindowState(state, 'wharness:windows:restart-intent', { scope, currentWindowId: windowState.id, affected: scope === 'all' || state.id === windowState.id })
    }
    return { ok: true, scope, windowCount: desktopWindows.size }
  })
  ipcMain.handle('wharness:chatgpt:show', async (event, request) => {
    const windowState = trustedSender(event)
    windowState.chatgptVisible = true
    const entry = activateChatGPTView(request?.cacheKey, request?.bounds, windowState)
    await waitForChatGPTSurfaceReady(request?.cacheKey, entry)
    return { ok: true }
  })
  ipcMain.handle('wharness:chatgpt:hide', (event, request) => {
    const windowState = trustedSender(event)
    const key = sanitizeChatCacheKey(request?.cacheKey)
    const entry = chatgptViews.get(key)
    if (entry?.ownerWindowId === windowState.id) entry.view.setVisible(false)
    if (windowState.activeChatGPTKey === key) windowState.chatgptVisible = false
    return { ok: true }
  })
  ipcMain.handle('wharness:chatgpt:set-bounds', (event, request) => {
    const windowState = trustedSender(event)
    const key = sanitizeChatCacheKey(request?.cacheKey)
    if (key !== windowState.activeChatGPTKey || !windowState.chatgptVisible) return { ok: false }
    return { ok: setChatGPTBounds(request?.bounds, windowState) }
  })
  ipcMain.handle('wharness:chatgpt:navigate', async (event, request) => {
    const windowState = trustedSender(event)
    const key = sanitizeChatCacheKey(request?.cacheKey)
    const target = requireTrustedChatGPTURL(request?.url || CHATGPT_URL)
    const entry = activateChatGPTView(key, undefined, windowState)
    const wc = entry.view.webContents
    const current = wc.getURL()
    const linkedConversation = canonicalChatGPTConversationURL(target)
    const targetIsHome = target === CHATGPT_URL
    const unboundHomeIntent = Boolean(request?.resetToHomeIfConversation && targetIsHome && !linkedConversation)
    syncChatGPTAffinityURL(key, entry, linkedConversation)
    const resetToHome = Boolean(unboundHomeIntent && chatGPTConversationID(current))
    const keepCachedDOM = !resetToHome && targetIsHome && isTrustedChatGPTOrigin(current) && current !== 'about:blank'
    if (resetToHome || (!keepCachedDOM && current !== target && !sameConversationURL(current, target))) {
      await wc.loadURL(target, { userAgent: CHATGPT_USER_AGENT })
    }
    if (!linkedConversation) observeChatGPTAffinityURL(key, entry, wc.getURL())
    return currentChatGPTState(key, windowState)
  })
  ipcMain.handle('wharness:chatgpt:confirm-affinity', (event, request) => {
    const windowState = trustedSender(event)
    const key = sanitizeChatCacheKey(request?.cacheKey)
    const { entry } = ensureChatGPTView(key, windowState)
    const { wc } = requireOwnedChatGPTEntry(key, entry)
    const confirmedURL = confirmChatGPTAffinity(entry.affinity, request?.conversationUrl, wc.getURL())
    console.log(`[chatgpt-affinity] confirmed key=${key} url=${sanitizeDiagnosticURL(confirmedURL)}`)
    publishChatGPTState(key)
    return { ok: true, cacheKey: key, conversationUrl: confirmedURL, ...publicChatGPTAffinity(entry.affinity) }
  })
  ipcMain.handle('wharness:chatgpt:reject-affinity', async (event, request) => {
    const windowState = trustedSender(event)
    const key = sanitizeChatCacheKey(request?.cacheKey)
    const { entry } = ensureChatGPTView(key, windowState)
    const { wc } = requireOwnedChatGPTEntry(key, entry)
    const rejectedURL = canonicalChatGPTConversationURL(request?.conversationUrl || '')
    rejectChatGPTAffinity(entry.affinity, rejectedURL)
    const fallbackURL = entry.affinity.boundURL || CHATGPT_URL
    if (rejectedURL && sameConversationURL(wc.getURL(), rejectedURL) && !sameConversationURL(wc.getURL(), fallbackURL)) {
      await wc.loadURL(fallbackURL, { userAgent: CHATGPT_USER_AGENT })
    }
    if (!entry.affinity.boundURL) observeChatGPTAffinityURL(key, entry, wc.getURL())
    console.log(`[chatgpt-affinity] rejected key=${key} url=${sanitizeDiagnosticURL(rejectedURL)}`)
    publishChatGPTState(key)
    return { ok: true, cacheKey: key, ...publicChatGPTAffinity(entry.affinity) }
  })
  ipcMain.handle('wharness:chatgpt:reload', (event, request) => { const windowState = trustedSender(event); const { entry } = ensureChatGPTView(request?.cacheKey, windowState); requireOwnedChatGPTEntry(request?.cacheKey, entry).wc.reload(); return { ok: true } })
  ipcMain.handle('wharness:chatgpt:focus', (event, request) => { const windowState = trustedSender(event); const { entry } = ensureChatGPTView(request?.cacheKey, windowState); requireOwnedChatGPTEntry(request?.cacheKey, entry).wc.focus(); return { ok: true } })
  ipcMain.handle('wharness:chatgpt:back', (event, request) => {
    const windowState = trustedSender(event)
    const { entry } = ensureChatGPTView(request?.cacheKey, windowState)
    const { wc } = requireOwnedChatGPTEntry(request?.cacheKey, entry)
    if (wc.navigationHistory.canGoBack()) wc.navigationHistory.goBack()
    return { ok: true }
  })
  ipcMain.handle('wharness:chatgpt:forward', (event, request) => {
    const windowState = trustedSender(event)
    const { entry } = ensureChatGPTView(request?.cacheKey, windowState)
    const { wc } = requireOwnedChatGPTEntry(request?.cacheKey, entry)
    if (wc.navigationHistory.canGoForward()) wc.navigationHistory.goForward()
    return { ok: true }
  })
  ipcMain.handle('wharness:chatgpt:state', (event, request) => { const windowState = trustedSender(event); return currentChatGPTState(request?.cacheKey, windowState) })
  ipcMain.handle('wharness:chatgpt:release', (event, request) => { const windowState = trustedSender(event); return { ok: true, released: releaseChatGPTView(request?.cacheKey, windowState) } })
  ipcMain.handle('wharness:chatgpt:set-auth-mode', async (event, request) => {
    const windowState = trustedSender(event)
    const mode = sanitizeChatGPTAuthMode(request?.mode)
    const { key, entry } = ensureChatGPTView(request?.cacheKey, windowState)
    requireOwnedChatGPTEntry(key, entry)
    entry.authMode = mode
    if (mode === 'embedded') {
      cancelExternalAuthentication(key)
      entry.externalAuthProvider = ''
      if (windowState.activeChatGPTKey === key) entry.view.setVisible(windowState.chatgptVisible)
    }
    publishChatGPTState(key)
    return currentChatGPTState(key, windowState)
  })
  ipcMain.handle('wharness:chatgpt:start-auth', async (event, request) => {
    const windowState = trustedSender(event)
    const mode = sanitizeChatGPTAuthMode(request?.mode)
    const { key, entry } = ensureChatGPTView(request?.cacheKey, windowState)
    requireOwnedChatGPTEntry(key, entry)
    entry.authMode = mode
    entry.externalAuthProvider = ''
    entry.embeddedAuthActive = mode === 'embedded'
    entry.embeddedAuthCrossedBoundary = false
    if (mode === 'external') {
      cancelExternalAuthentication(key)
      startExternalAuthentication(entry, 'OpenAI')
      return currentChatGPTState(key, windowState)
    }
    cancelExternalAuthentication(key)
    await entry.view.webContents.loadURL(CHATGPT_LOGIN_URL, { userAgent: CHATGPT_USER_AGENT })
    requireOwnedChatGPTEntry(key, entry)
    if (windowState.activeChatGPTKey === key) entry.view.setVisible(windowState.chatgptVisible)
    publishChatGPTState(key)
    return currentChatGPTState(key, windowState)
  })
  ipcMain.handle('wharness:chatgpt:open-external', async (event, request) => {
    trustedSender(event)
    const target = requireTrustedChatGPTURL(request?.url || CHATGPT_URL)
    await shell.openExternal(target)
    return { ok: true }
  })
  ipcMain.handle('wharness:chatgpt:resume-embedded', async (event, request) => {
    const windowState = trustedSender(event)
    const { key, entry } = ensureChatGPTView(request?.cacheKey, windowState)
    const { wc } = requireOwnedChatGPTEntry(key, entry)
    entry.externalAuthProvider = ''
    entry.authMode = 'embedded'
    cancelExternalAuthentication(key)
    if (!isTrustedChatGPTOrigin(wc.getURL())) await wc.loadURL(CHATGPT_URL, { userAgent: CHATGPT_USER_AGENT })
    requireOwnedChatGPTEntry(key, entry)
    if (windowState.activeChatGPTKey === key) entry.view.setVisible(windowState.chatgptVisible)
    publishChatGPTState(key)
    return currentChatGPTState(key, windowState)
  })
  ipcMain.handle('wharness:chatgpt:pick-bundle', async (event, request) => {
    const windowState = trustedSender(event)
    const requestId = String(request?.requestId || '').trim()
    const expectedFilename = canonicalBundleFilename(requestId)
    const result = await dialog.showOpenDialog(windowState.window, {
      title: `Selecionar ${expectedFilename}`,
      defaultPath: app.getPath('downloads'),
      properties: ['openFile'],
      filters: [{ name: 'Wharness bundle ZIP', extensions: ['zip'] }],
    })
    if (result.canceled || result.filePaths.length === 0) return { cancelled: true }
    const filePath = result.filePaths[0]
    const sourceFilename = path.basename(filePath)
    const bytes = await readFile(filePath)
    if (bytes.byteLength > MAX_EXECUTION_BUNDLE_BYTES) throw new Error('Bundle Wharness excede o limite de 16 MiB.')
    const candidate = canonicalWharnessBundleDownload(sourceFilename, requestId, 'application/zip')
    if (!candidate) throw new Error('O ficheiro selecionado não é um bundle ZIP Wharness reconhecível.')
    const validated = validateWharnessBundleDownload(candidate.filename, bytes)
    if (validated.requestId !== requestId) throw new Error('O bundle selecionado não pertence ao pedido ativo.')
    return {
      cancelled: false,
      filename: candidate.filename,
      requestId: validated.requestId,
      sourceFilename,
      normalizedFilename: candidate.normalized,
      bytes: bytes.byteLength,
      contentBase64: bytes.toString('base64'),
    }
  })
  ipcMain.handle('wharness:chatgpt:paste', (event, request) => { const windowState = trustedSender(event); const { entry } = ensureChatGPTView(request?.cacheKey, windowState); requireOwnedChatGPTEntry(request?.cacheKey, entry).wc.paste(); return { ok: true } })
  ipcMain.handle('wharness:chatgpt:submit-prompt', async (event, request) => {
    const windowState = trustedSender(event)
    ensureChatGPTView(request?.cacheKey, windowState)
    return submitPromptToChatGPT(request?.cacheKey, request?.text, request?.url, request?.requestId)
  })
  ipcMain.handle('wharness:chatgpt:prepare-prompt', async (event, request) => {
    const windowState = trustedSender(event)
    ensureChatGPTView(request?.cacheKey, windowState)
    return preparePromptForChatGPT(request)
  })
  ipcMain.handle('wharness:chatgpt:attach-context', async (event, request) => {
    const windowState = trustedSender(event)
    ensureChatGPTView(request?.cacheKey, windowState)
    return attachContextToChatGPT(request)
  })
  ipcMain.handle('wharness:chatgpt:attach-prompt', async (event, request) => {
    const windowState = trustedSender(event)
    ensureChatGPTView(request?.cacheKey, windowState)
    return attachPromptToChatGPT(request)
  })
  ipcMain.handle('wharness:chatgpt:submit-prepared', async (event, request) => {
    const windowState = trustedSender(event)
    ensureChatGPTView(request?.cacheKey, windowState)
    return submitPreparedChatGPTDraft(request?.cacheKey)
  })
  ipcMain.handle('wharness:chatgpt:queue-comment', async (event, request) => {
    const windowState = trustedSender(event)
    ensureChatGPTView(request?.cacheKey, windowState)
    return queueChatGPTComment(request)
  })
  ipcMain.handle('wharness:data:storage', async (event) => { trustedSender(event); return desktopStorageUsage() })
  ipcMain.handle('wharness:data:export-browser-session', async (event) => { const windowState = trustedSender(event); return exportBrowserSession(windowState) })
  ipcMain.handle('wharness:data:import-browser-session', async (event) => { const windowState = trustedSender(event); return importBrowserSession(windowState) })
  ipcMain.handle('wharness:data:clear-browser-session', async (event) => { trustedSender(event); return clearBrowserSession() })
  ipcMain.handle('wharness:data:clear-all', async (event, request) => {
    trustedSender(event)
    if (String(request?.confirm || '').trim() !== 'APAGAR WHARNESS') throw new Error('Complete Wharness reset confirmation mismatch')
    return clearDesktopWharnessData()
  })
  ipcMain.handle('wharness:attachments:persist', async (event, request) => {
    trustedSender(event)
    const cacheKey = sanitizeChatCacheKey(request?.cacheKey)
    const messageId = sanitizeChatCacheKey(request?.messageId)
    const { decoded } = decodeChatAttachmentSet(request?.attachments || [])
    const attachments = await persistChatAttachmentFiles(chatAttachmentRoot(), cacheKey, messageId, decoded, createPersistentAttachmentPreview)
    return { ok: true, attachments }
  })
  ipcMain.handle('wharness:attachments:preview', async (event, request) => {
    trustedSender(event)
    try { return await readStoredAttachmentPreview(chatAttachmentRoot(), request?.storageRef) }
    catch { return { available: false, dataUrl: '', previewKind: 'none' } }
  })
  ipcMain.handle('wharness:attachments:open', async (event, request) => {
    trustedSender(event)
    const filePath = await storedAttachmentPath(chatAttachmentRoot(), request?.storageRef)
    const error = await shell.openPath(filePath)
    if (error) throw new Error(`Não foi possível abrir o anexo: ${error}`)
    return { ok: true }
  })
  ipcMain.handle('wharness:attachments:remove-chat', async (event, request) => {
    trustedSender(event)
    const cacheKey = sanitizeChatCacheKey(request?.cacheKey)
    await removeStoredChatAttachments(chatAttachmentRoot(), cacheKey)
    return { ok: true }
  })
  ipcMain.handle('wharness:clipboard:read-text', (event) => { trustedSender(event); return clipboard.readText() })
  ipcMain.handle('wharness:clipboard:write-text', async (event, value) => {
    trustedSender(event)
    const text = String(value || '')
    if (text.length > 4 * 1024 * 1024) throw new Error('Clipboard text exceeds 4 MiB limit')
    await clipboard.writeText(text)
    return { ok: true }
  })
  ipcMain.handle('wharness:clipboard:copy-context-zip', async (event, request) => {
    trustedSender(event)
    const { id: sessionId, bytes } = await fetchContextZip(request?.sessionId)

    const dir = path.join(app.getPath('temp'), 'wharness-context', sessionId)
    await mkdir(dir, { recursive: true })
    const filePath = path.join(dir, `wharness-context-${sessionId}.zip`)
    await writeFile(filePath, bytes, { mode: 0o600 })
    await clipboard.write([new ClipboardItem({ 'text/uri-list': `${pathToFileURL(filePath).href}\r\n` })])
    return { ok: true, bytes: bytes.byteLength }
  })
}

app.whenReady().then(async () => {
  try { await applyPendingBrowserSessionImport() } catch (error) { console.error('[chatgpt-session] pending import failed', error) }
  const chatSession = session.fromPartition(CHATGPT_PARTITION)
  chatSession.setUserAgent(CHATGPT_USER_AGENT, CHATGPT_ACCEPT_LANGUAGES)
  registerChatGPTPlanDownloads(chatSession)

  const remoteFilter = {
    urls: [
      'https://chatgpt.com/*',
      'https://*.chatgpt.com/*',
      'https://*.openai.com/*',
    ],
  }
  chatSession.webRequest.onBeforeRequest(remoteFilter, (details, callback) => {
    noteChatGPTNetworkActivity(details, 'before')
    chatGPTUploads.onBeforeRequest(details)
    chatGPTSubmissions.onBeforeRequest(details)
    callback({})
  })
  chatSession.webRequest.onErrorOccurred(remoteFilter, (details) => {
    noteChatGPTNetworkActivity(details, 'error')
    noteChatGPTNetworkFailure(details)
    chatGPTUploads.onErrorOccurred(details)
    console.error(`[chatgpt-net] ${details.method} ${sanitizeDiagnosticURL(details.url)} error=${details.error}`)
  })
  chatSession.webRequest.onCompleted(remoteFilter, (details) => {
    noteChatGPTNetworkActivity(details, 'completed')
    chatGPTUploads.onCompleted(details)
    if (details.statusCode >= 400) {
      console.error(`[chatgpt-http] ${details.method} ${sanitizeDiagnosticURL(details.url)} status=${details.statusCode}`)
    }
  })

  // Remote ChatGPT gets the minimum browser permissions it needs. In particular,
  // navigator.clipboard.writeText() maps to clipboard-sanitized-write in Electron.
  // We deliberately do NOT grant clipboard-read: importing a response remains an
  // explicit Wharness action owned by the trusted local renderer/main process.
  chatSession.setPermissionRequestHandler((webContents, permission, callback, details) => {
    const requestingURL = details?.requestingUrl || webContents?.getURL() || ''
    const trusted = isTrustedChatGPTOrigin(requestingURL)
    const allowed = trusted && (permission === 'notifications' || permission === 'clipboard-sanitized-write')
    if (permission.startsWith('clipboard')) {
      console.log(`[chatgpt-permission] ${permission} origin=${sanitizeDiagnosticURL(requestingURL)} allowed=${allowed}`)
    }
    callback(allowed)
  })
  chatSession.setPermissionCheckHandler((_webContents, permission, requestingOrigin, details) => {
    const requestingURL = details?.requestingUrl || requestingOrigin || details?.embeddingOrigin || ''
    const trusted = isTrustedChatGPTOrigin(requestingURL)
    return trusted && (permission === 'notifications' || permission === 'clipboard-sanitized-write')
  })

  // Keep the local Wharness composer useful in Portuguese while preserving
  // English for code/technical terms. Electron only accepts dictionaries that
  // are actually available in the current Chromium build.
  try {
    const available = new Set(session.defaultSession.availableSpellCheckerLanguages || [])
    const preferred = ['pt-PT', 'pt-BR', 'en-US'].filter((language) => available.has(language))
    if (preferred.length) session.defaultSession.setSpellCheckerLanguages(preferred)
  } catch (error) { console.warn('[spellcheck] dictionary configuration failed', error) }

  // Cache only: preserve cookies/login while forcing current ChatGPT assets to reload
  // under the Chrome-compatible UA. Failures here must not prevent startup.
  try { await chatSession.clearCache() } catch (error) { console.error('[chatgpt-cache] clear failed', error) }

  console.log(`ChatGPT compatibility UA: Chrome/${CHATGPT_CHROMIUM_VERSION}`)
  registerIPC()
  chatGPTDownloadPoller = setInterval(() => { void pollExpectedChatGPTDownloads(); void flushQueuedChatGPTComments(); void pollChatGPTVisibleActivity() }, DOM_DOWNLOAD_POLL_MS)

  const layout = loadWindowLayout()
  const restartIntent = consumeRestartIntent()
  if (restartIntent?.scope === 'current' && layout.includes(restartIntent.currentWindowId)) {
    // A process-level self-evolution restart cannot physically keep sibling windows
    // alive. Recreate the requesting window first, then restore the saved topology.
    createWindow(restartIntent.currentWindowId, false)
    persistWindowLayout(layout)
    setTimeout(() => {
      for (const windowId of layout) if (windowId !== restartIntent.currentWindowId && !desktopWindows.has(windowId)) createWindow(windowId, false)
      persistWindowLayout()
    }, 900)
  } else {
    for (const windowId of layout) createWindow(windowId, false)
    persistWindowLayout()
  }
})

app.on('before-quit', () => { quitting = true; persistWindowLayout(); if (chatGPTDownloadPoller) clearInterval(chatGPTDownloadPoller) })
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow('primary') })
