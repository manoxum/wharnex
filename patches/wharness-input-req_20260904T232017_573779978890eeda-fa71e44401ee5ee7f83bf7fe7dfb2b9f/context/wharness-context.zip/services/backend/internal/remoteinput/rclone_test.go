package remoteinput

import "testing"

func TestNormalizeRclonePublishedURLConvertsGoogleDriveViewerToRawDownload(t *testing.T) {
	got, err := normalizeRclonePublishedURL("drive", "https://drive.google.com/open?id=1AbC_def-234")
	if err != nil {
		t.Fatal(err)
	}
	want := "https://drive.usercontent.google.com/download?id=1AbC_def-234&export=download&confirm=t"
	if got.String() != want {
		t.Fatalf("got %q, want %q", got.String(), want)
	}
}

func TestNormalizeRclonePublishedURLRejectsUnknownGoogleDriveViewerShape(t *testing.T) {
	if _, err := normalizeRclonePublishedURL("drive", "https://drive.google.com/drive/my-drive"); err == nil {
		t.Fatal("expected a non-file Google Drive viewer URL to be rejected")
	}
}

func TestNormalizeRclonePublishedURLLeavesOtherProvidersUnchanged(t *testing.T) {
	got, err := normalizeRclonePublishedURL("dropbox", "https://dropbox.example/download/archive.zip")
	if err != nil {
		t.Fatal(err)
	}
	if got.String() != "https://dropbox.example/download/archive.zip" {
		t.Fatalf("unexpected URL: %q", got.String())
	}
}
