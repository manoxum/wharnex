package domain

import (
	"encoding/json"
	"time"
)

const ProtocolV1 = "harness.execution/v1"
const TurnProtocolV1 = "harness.turn/v1"

type TurnKind string

const (
	TurnKindAnswer        TurnKind = "answer"
	TurnKindClarification TurnKind = "clarification"
	TurnKindInvestigation TurnKind = "investigation"
	TurnKindWorkflow      TurnKind = "workflow"
	TurnKindChange        TurnKind = "change"
	TurnKindBlocked       TurnKind = "blocked"
)

func ValidTurnKind(kind TurnKind) bool {
	switch kind {
	case TurnKindAnswer, TurnKindClarification, TurnKindInvestigation, TurnKindWorkflow, TurnKindChange, TurnKindBlocked:
		return true
	default:
		return false
	}
}

type AgentTurn struct {
	Protocol  string   `json:"protocol"`
	RequestID string   `json:"request_id"`
	Kind      TurnKind `json:"kind"`
	Message   string   `json:"message"`
}

type ExecutionMode string

const (
	ExecutionModeProtected   ExecutionMode = "protected"
	ExecutionModeUnprotected ExecutionMode = "unprotected"
)

func ValidExecutionMode(mode ExecutionMode) bool {
	return mode == ExecutionModeProtected || mode == ExecutionModeUnprotected
}

type AutomationMode string

const (
	AutomationModeManual AutomationMode = "manual"
	AutomationModeAuto   AutomationMode = "auto"
)

func ValidAutomationMode(mode AutomationMode) bool {
	return mode == AutomationModeManual || mode == AutomationModeAuto
}

type TerminalTarget string

const (
	TerminalTargetSandbox TerminalTarget = "sandbox"
	TerminalTargetHost    TerminalTarget = "host"
)

func ValidTerminalTarget(target TerminalTarget) bool {
	return target == TerminalTargetSandbox || target == TerminalTargetHost
}

type CommandSpec struct {
	Argv              []string `json:"argv"`
	Cwd               string   `json:"cwd"`
	TimeoutSeconds    int      `json:"timeout_seconds"`
	Network           bool     `json:"network"`
	ExpectedExitCodes []int    `json:"expected_exit_codes"`
}

type Operation struct {
	Type    string      `json:"type"`
	Patch   string      `json:"patch"`
	Command CommandSpec `json:"command"`
}

type ExecutionPlan struct {
	Protocol          string        `json:"protocol"`
	BaseContextSHA256 string        `json:"base_context_sha256,omitempty"`
	ImpactFiles       []string      `json:"impact_files,omitempty"`
	PlanID            string        `json:"plan_id"`
	RequestID         string        `json:"request_id"`
	Status            string        `json:"status"`
	Summary           string        `json:"summary"`
	Risk              string        `json:"risk"`
	RequiresApproval  bool          `json:"requires_approval"`
	Operations        []Operation   `json:"operations"`
	Verification      []CommandSpec `json:"verification"`
}

type PolicyDecision struct {
	Allowed          bool     `json:"allowed"`
	RequiresApproval bool     `json:"requires_approval"`
	Risk             string   `json:"risk"`
	Reasons          []string `json:"reasons"`
}

type CommandResult struct {
	Argv             []string `json:"argv"`
	Cwd              string   `json:"cwd"`
	ExitCode         int      `json:"exit_code"`
	Stdout           string   `json:"stdout"`
	Stderr           string   `json:"stderr"`
	DurationMS       int64    `json:"duration_ms"`
	Success          bool     `json:"success"`
	BaselineFailure  bool     `json:"baseline_failure,omitempty"`
	BaselineExitCode int      `json:"baseline_exit_code,omitempty"`
	BaselineOutput   string   `json:"baseline_output,omitempty"`
}

type ExecutionBundleInfo struct {
	Filename string   `json:"filename"`
	README   string   `json:"readme"`
	Files    []string `json:"files"`
	Patches  []string `json:"patches"`
	SHA256   string   `json:"sha256"`
}

type ExecutionResult struct {
	PlanID      string          `json:"plan_id"`
	Success     bool            `json:"success"`
	StartedAt   time.Time       `json:"started_at"`
	CompletedAt time.Time       `json:"completed_at"`
	Commands    []CommandResult `json:"commands"`
	Error       string          `json:"error,omitempty"`
	Warnings    []string        `json:"warnings,omitempty"`
}

func (r ExecutionResult) MarshalJSON() ([]byte, error) {
	type executionResult ExecutionResult
	if r.Commands == nil {
		r.Commands = []CommandResult{}
	}
	return json.Marshal(executionResult(r))
}

// BaselineNotice records one project-context transition observed by a peer
// session. CompleteDelta is false when Wharness could not prove that the peer
// observed the immediately preceding baseline, disabling optimistic fast-forward.
type BaselineNotice struct {
	ID              string    `json:"id"`
	SourceSessionID string    `json:"source_session_id"`
	SourcePlanID    string    `json:"source_plan_id"`
	PreviousSHA256  string    `json:"previous_sha256"`
	NewSHA256       string    `json:"new_sha256"`
	ChangedFiles    []string  `json:"changed_files"`
	OverlapFiles    []string  `json:"overlap_files,omitempty"`
	Relevant        bool      `json:"relevant"`
	CompleteDelta   bool      `json:"complete_delta"`
	CreatedAt       time.Time `json:"created_at"`
}

// PendingHostChange is a Protected plan that has passed sandbox verification
// but has not yet been accepted into the host project. Keeping the plan and its
// execution together lets later plans verify against the cumulative candidate
// without making the host the source of truth prematurely.
type PendingHostChange struct {
	Plan       ExecutionPlan   `json:"plan"`
	Execution  ExecutionResult `json:"execution"`
	VerifiedAt time.Time       `json:"verified_at"`
}

type ContextFile struct {
	Path   string `json:"path"`
	Size   int64  `json:"size"`
	SHA256 string `json:"sha256"`
}

type ContextExclusion struct {
	Path   string `json:"path"`
	Kind   string `json:"kind"`
	Reason string `json:"reason"`
	Rule   string `json:"rule"`
}

type ContextManifest struct {
	ID              string             `json:"id"`
	ProjectRoot     string             `json:"project_root"`
	SHA256          string             `json:"sha256"`
	Files           []ContextFile      `json:"files"`
	Excluded        []string           `json:"excluded"`
	ExcludedDetails []ContextExclusion `json:"excluded_details,omitempty"`
	TextTruncated   bool               `json:"text_truncated"`
}

type ContextBundle struct {
	ID       string          `json:"id"`
	ZipPath  string          `json:"-"`
	TextPath string          `json:"-"`
	Manifest ContextManifest `json:"manifest"`
}

type Session struct {
	ID                      string               `json:"id"`
	ProjectPath             string               `json:"project_path"`
	ExecutionMode           ExecutionMode        `json:"execution_mode"`
	AutomationMode          AutomationMode       `json:"automation_mode"`
	SelfEvolution           bool                 `json:"self_evolution,omitempty"`
	SelfEvolutionActivation string               `json:"self_evolution_activation,omitempty"`
	State                   string               `json:"state"`
	CreatedAt               time.Time            `json:"created_at"`
	Context                 ContextBundle        `json:"context"`
	Plan                    *ExecutionPlan       `json:"plan,omitempty"`
	Policy                  *PolicyDecision      `json:"policy,omitempty"`
	LastExecution           *ExecutionResult     `json:"last_execution,omitempty"`
	PendingHostChanges      []PendingHostChange  `json:"pending_host_changes,omitempty"`
	LastAppliedChanges      []PendingHostChange  `json:"last_applied_changes,omitempty"`
	LastProviderResponseID  string               `json:"last_provider_response_id,omitempty"`
	LastRequestID           string               `json:"last_request_id,omitempty"`
	PendingManualRequestIDs []string             `json:"pending_manual_request_ids,omitempty"`
	LastManualPrompt        string               `json:"last_manual_prompt,omitempty"`
	LastBundle              *ExecutionBundleInfo `json:"last_bundle,omitempty"`
	LastTurn                *AgentTurn           `json:"last_turn,omitempty"`
	RepairAttempt           int                  `json:"repair_attempt,omitempty"`
	RepairParentPlanID      string               `json:"repair_parent_plan_id,omitempty"`
	LastRepairError         string               `json:"last_repair_error,omitempty"`
	WorkflowRound           int                  `json:"workflow_round,omitempty"`
	LastRequestMode         string               `json:"last_request_mode,omitempty"`
	PlannerInFlight         bool                 `json:"planner_in_flight,omitempty"`
	RequestBaselines        map[string]string    `json:"request_baselines,omitempty"`
	BaselineNotices         []BaselineNotice     `json:"baseline_notices,omitempty"`
}

type Event struct {
	ID        string         `json:"id"`
	SessionID string         `json:"session_id"`
	Type      string         `json:"type"`
	Timestamp time.Time      `json:"timestamp"`
	Data      map[string]any `json:"data"`
}
