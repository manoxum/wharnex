import type { ReactNode } from 'react'

export function StatusPill({ tone = 'neutral', children }: { tone?: 'neutral' | 'success' | 'warning' | 'danger' | 'accent'; children: ReactNode }) {
  return <span className={`status-pill status-${tone}`}>{children}</span>
}
