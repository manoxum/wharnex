# Wharness automatic repair bundle

Request: `req_20260904T072258_5f91019618e713ac`

This is the corrected replacement plan for the same active Wharness change. The original product patch is retained because it applies cleanly to the supplied host snapshot. The failed backend verification was reproduced as a cross-package race: `ClearAllData` globally removed fresh `kernl-workspace-*` directories while the sandbox package was running npm/git inside one of them.

The second patch changes reset semantics to delete only artifacts explicitly owned by the current Service instance and adds a regression proving a foreign/active Protected workspace survives reset. The backend race regression passed repeatedly after the repair, followed by the broader backend gate.

## Patch checksums
- `001-wharness-v1.2.30-agent-ux-execution-diff.patch` — SHA-256 `b4d2b7eb74d9e2f4b8d9a82c75e324525e38771d14990988a2cc33005aebf840` — 213657 bytes
- `002-wharness-v1.2.30-repair-active-workspace-cleanup.patch` — SHA-256 `b13eb8df75dcb1c7017abfaace429e04c645fb68434ea6f8e13cce6e99a66efe` — 2428 bytes

## Declared verification

1. Re-run the concurrent ClearAllData/npm-workspace regression 10 times.
2. Run the broader backend app/sandbox/httpapi tests.
3. Run frontend tests, typecheck and lint.
4. Run the desktop check.

All executable project mutations remain represented only by the raw unified diffs under `patches/` and are intended for Wharness Protected verification before host apply.
