# Wharness Export Metadata

- Schema: `wharness.exports/v1`
- Kind: `managed-context`
- Project: `wharness`
- Project root: `/home/zootakuxy/workspace/wharness`
- VCS internals: `.git` is excluded from the archive; Git state is captured below for analysis.
- Git remotes: intentionally omitted to avoid exporting credential-bearing URLs.

## Git summary

- Git available: `true`
- Git repository: `true`
- Repository root: `/home/zootakuxy/workspace/wharness`
- Branch: `main`
- HEAD: `3fe4c244cbb130a0bbcb1017cd3f1740afd57995`

## Git status

```text
## main...origin/main
 M SoT/AUTOMATION_BUNDLE.md
 M SoT/CONTEXT_PROTOCOL.md
 M SoT/SECURITY_MODEL.md
 M adr/ADR-0020-remote-input-storage.md
 M docs/getting-started.md
 M services/backend/internal/app/remote_storage_connector.go
 M services/backend/internal/app/service_remote_input.go
 M services/backend/internal/app/service_remote_input_test.go
 M services/backend/internal/remoteinput/rclone.go
 M services/backend/internal/remoteinput/rclone_connector.go
 M services/backend/internal/remoteinput/rclone_connector_test.go
 M services/desktop/chatgpt-recovery.mjs
 M services/desktop/chatgpt-recovery.test.mjs
 M services/desktop/main-regression.test.mjs
 M services/desktop/main.mjs
 M services/frontend/src/components/RemoteStorageSettings.test.tsx
 M services/frontend/src/components/RemoteStorageSettings.tsx
?? services/backend/internal/remoteinput/rclone_test.go
```

## Git worktrees

```text
worktree /home/zootakuxy/workspace/wharness
HEAD 3fe4c244cbb130a0bbcb1017cd3f1740afd57995
branch refs/heads/main
```
